import { Coordinates, CalculationMethod, PrayerTimes, Qibla, Madhab } from 'adhan';
import { CalculationMethodKey, MadhabKey, PrayerTimeItem } from '../types';

export interface CalculatedTimesResult {
  fajr: Date;
  sunrise: Date;
  dhuhr: Date;
  asr: Date;
  maghrib: Date;
  isha: Date;
  tahajjud: Date;
}

export function getCalculationMethodParameters(methodKey: CalculationMethodKey) {
  switch (methodKey) {
    case 'Karachi':
      return CalculationMethod.Karachi();
    case 'MWL':
      return CalculationMethod.MuslimWorldLeague();
    case 'ISNA':
      return CalculationMethod.NorthAmerica();
    case 'UmmAlQura':
      return CalculationMethod.UmmAlQura();
    case 'Egypt':
      return CalculationMethod.Egyptian();
    case 'Dubai':
      return CalculationMethod.Dubai();
    case 'Qatar':
      return CalculationMethod.Qatar();
    case 'Kuwait':
      return CalculationMethod.Kuwait();
    case 'Singapore':
      return CalculationMethod.Singapore();
    case 'Tehran':
      return CalculationMethod.Tehran();
    default:
      return CalculationMethod.Karachi();
  }
}

export function calculatePrayerTimes(
  date: Date,
  latitude: number,
  longitude: number,
  methodKey: CalculationMethodKey = 'Karachi',
  madhabKey: MadhabKey = 'hanafi'
): CalculatedTimesResult {
  const coordinates = new Coordinates(latitude, longitude);
  const params = getCalculationMethodParameters(methodKey);

  if (madhabKey === 'hanafi') {
    params.madhab = Madhab.Hanafi;
  } else {
    params.madhab = Madhab.Shafi;
  }

  const prayerTimes = new PrayerTimes(coordinates, date, params);

  // Tahajjud calculation: last third of night (between Isha and next day Fajr)
  const tomorrow = new Date(date);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowPrayers = new PrayerTimes(coordinates, tomorrow, params);

  const nightStart = prayerTimes.maghrib.getTime();
  const nightEnd = tomorrowPrayers.fajr.getTime();
  const nightDuration = nightEnd - nightStart;
  const lastThirdStart = new Date(nightStart + (nightDuration * 2) / 3);

  return {
    fajr: prayerTimes.fajr,
    sunrise: prayerTimes.sunrise,
    dhuhr: prayerTimes.dhuhr,
    asr: prayerTimes.asr,
    maghrib: prayerTimes.maghrib,
    isha: prayerTimes.isha,
    tahajjud: lastThirdStart,
  };
}

export function formatTime24(date: Date): string {
  const h = String(date.getHours()).padStart(2, '0');
  const m = String(date.getMinutes()).padStart(2, '0');
  return `${h}:${m}`;
}

export function formatTime12(dateOrHHmm: Date | string): { time: string; ap: string; display: string } {
  let h = 0;
  let m = 0;
  if (typeof dateOrHHmm === 'string') {
    const parts = dateOrHHmm.split(':');
    h = parseInt(parts[0], 10) || 0;
    m = parseInt(parts[1], 10) || 0;
  } else {
    h = dateOrHHmm.getHours();
    m = dateOrHHmm.getMinutes();
  }

  const ap = h >= 12 ? 'PM' : 'AM';
  const h12 = h % 12 || 12;
  const mStr = String(m).padStart(2, '0');
  return {
    time: `${h12}:${mStr}`,
    ap,
    display: `${h12}:${mStr} ${ap}`,
  };
}

export function formatDisplayTime(dateOrHHmm: Date | string, is24h: boolean = false): string {
  if (is24h) {
    if (typeof dateOrHHmm === 'string') return dateOrHHmm;
    return formatTime24(dateOrHHmm);
  }
  return formatTime12(dateOrHHmm).display;
}

export function getIslamicDateString(date: Date = new Date()): { gregorian: string; hijri: string } {
  const gregorian = date.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

  let hijri = '';
  try {
    const hijriFormatter = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
    hijri = hijriFormatter.format(date) + ' AH';
  } catch {
    try {
      const fallbackFormatter = new Intl.DateTimeFormat('en-u-ca-islamic', {
        day: 'numeric',
        month: 'long',
        year: 'numeric',
      });
      hijri = fallbackFormatter.format(date);
    } catch {
      hijri = 'Islamic Calendar';
    }
  }

  return { gregorian, hijri };
}

/**
 * Calculate Qibla bearing from latitude & longitude towards Kaaba
 */
export function calculateQiblaDirection(latitude: number, longitude: number): {
  bearing: number;
  distanceKm: number;
} {
  const coordinates = new Coordinates(latitude, longitude);
  const bearing = Qibla(coordinates);

  // Kaaba coordinates
  const kaabaLat = 21.422487;
  const kaabaLng = 39.826206;

  // Haversine distance
  const R = 6371; // Earth radius in km
  const dLat = ((kaabaLat - latitude) * Math.PI) / 180;
  const dLon = ((kaabaLng - longitude) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((latitude * Math.PI) / 180) *
      Math.cos((kaabaLat * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distanceKm = Math.round(R * c);

  return {
    bearing: Math.round(bearing),
    distanceKm,
  };
}

export const POPULAR_CITIES = [
  { city: 'Karachi', country: 'Pakistan', latitude: 24.8607, longitude: 67.0011 },
  { city: 'Lahore', country: 'Pakistan', latitude: 31.5204, longitude: 74.3587 },
  { city: 'Islamabad', country: 'Pakistan', latitude: 33.6844, longitude: 73.0479 },
  { city: 'Makkah', country: 'Saudi Arabia', latitude: 21.3891, longitude: 39.8579 },
  { city: 'Madinah', country: 'Saudi Arabia', latitude: 24.5247, longitude: 39.5692 },
  { city: 'Dubai', country: 'UAE', latitude: 25.2048, longitude: 55.2708 },
  { city: 'London', country: 'United Kingdom', latitude: 51.5074, longitude: -0.1278 },
  { city: 'New York', country: 'United States', latitude: 40.7128, longitude: -74.006 },
  { city: 'Toronto', country: 'Canada', latitude: 43.6532, longitude: -79.3832 },
  { city: 'Istanbul', country: 'Turkey', latitude: 41.0082, longitude: 28.9784 },
  { city: 'Cairo', country: 'Egypt', latitude: 30.0444, longitude: 31.2357 },
  { city: 'Jakarta', country: 'Indonesia', latitude: -6.2088, longitude: 106.8456 },
  { city: 'Kuala Lumpur', country: 'Malaysia', latitude: 3.139, longitude: 101.6869 },
  { city: 'Dhaka', country: 'Bangladesh', latitude: 23.8103, longitude: 90.4125 },
  { city: 'Mumbai', country: 'India', latitude: 19.076, longitude: 72.8777 },
  { city: 'Sydney', country: 'Australia', latitude: -33.8688, longitude: 151.2093 },
];
