import { AlarmItem, AppSettings, TaskItem, TasbihState } from '../types';

export const ALL_DAYS = [0, 1, 2, 3, 4, 5, 6];

export const DEFAULT_ALARMS: AlarmItem[] = [
  { id: 'p1', p: 'Tahajjud', t: '04:00', l: '🫀 تہجد کی نماز + صلوۃ الحاجات کی نماز', on: true, d: [...ALL_DAYS] },
  { id: 'p2', p: 'Fajr', t: '04:35', l: '💗 نمازِ فجر', on: true, d: [...ALL_DAYS] },
  { id: 'p3', p: 'Zuhr', t: '13:30', l: '🫶 نمازِ ظہر', on: true, d: [...ALL_DAYS] },
  { id: 'p4', p: 'Asr', t: '16:20', l: '❤️ نمازِ عصر', on: true, d: [...ALL_DAYS] },
  { id: 'p5', p: 'Maghrib', t: '18:00', l: '🫶🤍 نمازِ مغرب', on: true, d: [...ALL_DAYS] },
  { id: 'p6', p: 'Isha', t: '19:15', l: '🫶 🫀 نمازِ عشاء', on: true, d: [...ALL_DAYS] },
];

export const DEFAULT_TASKS: TaskItem[] = [
  { id: 't1', n: '📖 Recite Surah Al-Mulk before sleep', t: '21:30', x: false, createdAt: Date.now() },
  { id: 't2', n: '✨ Morning and Evening Adhkar', t: '06:00', x: false, createdAt: Date.now() },
  { id: 't3', n: '📿 Read Durood Sharif 100 times on Friday', t: '12:00', x: false, createdAt: Date.now() },
];

export const DEFAULT_SETTINGS: AppSettings = {
  sound: 'native_tone',
  volume: 0.8,
  vibration: true,
  timeFormat24: false,
  calculationMethod: 'Karachi',
  madhab: 'hanafi',
  location: {
    city: 'Karachi',
    country: 'Pakistan',
    latitude: 24.8607,
    longitude: 67.0011,
    isAuto: false,
  },
  urduLabels: true,
};

const STORAGE_KEY = 'namaz-app-pro-v2';

export interface AppStoredState {
  alarms: AlarmItem[];
  tasks: TaskItem[];
  done: Record<string, Record<string, boolean>>; // date -> { prayerId: true }
  tasbih: TasbihState;
  settings: AppSettings;
}

export function loadStoredData(): AppStoredState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY) || localStorage.getItem('namaz-app');
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        alarms: Array.isArray(parsed.alarms) && parsed.alarms.length > 0 ? parsed.alarms : DEFAULT_ALARMS,
        tasks: Array.isArray(parsed.tasks) ? parsed.tasks : DEFAULT_TASKS,
        done: parsed.done || {},
        tasbih: parsed.tasbih || parsed.tas || { n: 0, goal: 33, selectedDhikrId: 'subhanallah' },
        settings: { ...DEFAULT_SETTINGS, ...(parsed.settings || {}) },
      };
    }
  } catch (e) {
    console.warn('Error loading stored Namaz data', e);
  }

  return {
    alarms: DEFAULT_ALARMS,
    tasks: DEFAULT_TASKS,
    done: {},
    tasbih: { n: 0, goal: 33, selectedDhikrId: 'subhanallah' },
    settings: DEFAULT_SETTINGS,
  };
}

export function saveStoredData(data: AppStoredState): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    // also keep the legacy key in sync for backwards compatibility
    localStorage.setItem(
      'namaz-app',
      JSON.stringify({
        alarms: data.alarms,
        tasks: data.tasks,
        done: data.done,
        tas: data.tasbih,
      })
    );
  } catch (e) {
    console.warn('Error saving stored Namaz data', e);
  }
}

export function getTodayKey(): string {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function calculatePrayerStreak(doneRecord: Record<string, Record<string, boolean>>): number {
  let streak = 0;
  const current = new Date();

  // Check day by day backwards
  for (let i = 0; i < 365; i++) {
    const d = new Date(current);
    d.setDate(d.getDate() - i);
    const pad = (n: number) => String(n).padStart(2, '0');
    const key = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
    const dayPrayers = doneRecord[key] || {};
    // Obligatory prayers are Fajr, Zuhr, Asr, Maghrib, Isha (p2, p3, p4, p5, p6)
    const required = ['p2', 'p3', 'p4', 'p5', 'p6'];
    const count = required.filter(p => dayPrayers[p]).length;

    if (i === 0) {
      // today may still be in progress
      if (count >= 5) {
        streak++;
      }
    } else {
      if (count >= 5) {
        streak++;
      } else {
        break;
      }
    }
  }
  return streak;
}
