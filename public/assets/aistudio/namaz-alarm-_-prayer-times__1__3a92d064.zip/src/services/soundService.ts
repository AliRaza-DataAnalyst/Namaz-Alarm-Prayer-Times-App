/**
 * Sound and Vibration Service for Namaz Alarm
 * Provides native-like alarm sounds using Web Audio API and vibration.
 */

class SoundService {
  private audioCtx: AudioContext | null = null;
  private isAlarmPlaying = false;
  private alarmInterval: number | null = null;
  private activeGainNodes: GainNode[] = [];
  private activeOscillators: OscillatorNode[] = [];

  private getContext(): AudioContext {
    if (!this.audioCtx || this.audioCtx.state === 'closed') {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.audioCtx = new AudioContextClass();
    }
    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume().catch(() => {});
    }
    return this.audioCtx;
  }

  /**
   * Unlock Web Audio context upon any user interaction (prevents silent alarms)
   */
  public unlockAudio() {
    try {
      const ctx = this.getContext();
      if (ctx.state === 'suspended') {
        ctx.resume().catch(() => {});
      }
    } catch {
      // ignore
    }
  }

  /**
   * Play the native ToneGenerator alert (similar to Android CDMA ALERT CALL GUARD)
   * 700ms tone with dual frequencies
   */
  public playNativeTone(durationMs = 700, gainLevel = 0.5) {
    try {
      const ctx = this.getContext();
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();

      osc1.type = 'sawtooth';
      osc1.frequency.setValueAtTime(800, ctx.currentTime);

      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(1000, ctx.currentTime);

      gain.gain.setValueAtTime(0.01, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(Math.max(0.01, gainLevel * 0.4), ctx.currentTime + 0.05);
      gain.gain.setValueAtTime(Math.max(0.01, gainLevel * 0.4), ctx.currentTime + (durationMs / 1000) - 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + (durationMs / 1000));

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);

      osc1.start();
      osc2.start();
      osc1.stop(ctx.currentTime + (durationMs / 1000));
      osc2.stop(ctx.currentTime + (durationMs / 1000));

      this.activeGainNodes.push(gain);
      this.activeOscillators.push(osc1, osc2);
    } catch (e) {
      console.warn('Audio tone error', e);
    }
  }

  /**
   * Melodic Azan Chime using soft sine harmonics
   */
  public playMelodicAzan(gainLevel = 0.5) {
    try {
      const ctx = this.getContext();
      // Islamic Maqam Bayati / Hijaz inspired meditative notes
      const notes = [
        { freq: 293.66, delay: 0.0, dur: 1.0 }, // D4
        { freq: 329.63, delay: 0.8, dur: 1.2 }, // E4
        { freq: 349.23, delay: 1.8, dur: 1.4 }, // F4
        { freq: 440.00, delay: 3.0, dur: 1.8 }, // A4
        { freq: 392.00, delay: 4.6, dur: 1.5 }, // G4
        { freq: 349.23, delay: 5.9, dur: 1.6 }, // F4
        { freq: 293.66, delay: 7.2, dur: 2.2 }, // D4 resolve
      ];

      notes.forEach(({ freq, delay, dur }) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, ctx.currentTime + delay);

        gain.gain.setValueAtTime(0.001, ctx.currentTime + delay);
        gain.gain.exponentialRampToValueAtTime(Math.max(0.01, gainLevel * 0.5), ctx.currentTime + delay + 0.2);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + delay + dur);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(ctx.currentTime + delay);
        osc.stop(ctx.currentTime + delay + dur);
        this.activeGainNodes.push(gain);
        this.activeOscillators.push(osc);
      });
    } catch (e) {
      console.warn('Melodic tone error', e);
    }
  }

  /**
   * Soft Peaceful Bell
   */
  public playSoftBell(gainLevel = 0.5) {
    try {
      const ctx = this.getContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5

      gain.gain.setValueAtTime(0.001, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(Math.max(0.01, gainLevel * 0.6), ctx.currentTime + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 2.5);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 2.5);

      this.activeGainNodes.push(gain);
      this.activeOscillators.push(osc);
    } catch (e) {
      console.warn('Bell tone error', e);
    }
  }

  /**
   * Double Chime
   */
  public playChime(gainLevel = 0.5) {
    try {
      const ctx = this.getContext();
      [659.25, 880.0].forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, ctx.currentTime + (i * 0.2));

        gain.gain.setValueAtTime(0.001, ctx.currentTime + (i * 0.2));
        gain.gain.exponentialRampToValueAtTime(Math.max(0.01, gainLevel * 0.4), ctx.currentTime + (i * 0.2) + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + (i * 0.2) + 1.2);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(ctx.currentTime + (i * 0.2));
        osc.stop(ctx.currentTime + (i * 0.2) + 1.2);

        this.activeGainNodes.push(gain);
        this.activeOscillators.push(osc);
      });
    } catch (e) {
      console.warn('Chime error', e);
    }
  }

  /**
   * Start looping alarm
   */
  public startAlarmLoop(soundType: 'native_tone' | 'melodic_azan' | 'soft_bell' | 'chime' = 'native_tone', volume = 0.8) {
    this.stopAlarm();
    this.isAlarmPlaying = true;

    const playCycle = () => {
      if (!this.isAlarmPlaying) return;

      if (soundType === 'melodic_azan') {
        this.playMelodicAzan(volume);
      } else if (soundType === 'soft_bell') {
        this.playSoftBell(volume);
      } else if (soundType === 'chime') {
        this.playChime(volume);
      } else {
        // Native tone alert
        this.playNativeTone(700, volume);
      }

      // Vibrate if available
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        try {
          navigator.vibrate([400, 200, 400]);
        } catch {
          // ignore
        }
      }
    };

    playCycle();

    const intervalTime = soundType === 'melodic_azan' ? 9500 : 1500;
    this.alarmInterval = window.setInterval(playCycle, intervalTime);
  }

  /**
   * Stop currently ringing alarm immediately and cancel all scheduled audio
   */
  public stopAlarm() {
    this.isAlarmPlaying = false;
    if (this.alarmInterval !== null) {
      clearInterval(this.alarmInterval);
      this.alarmInterval = null;
    }

    try {
      const ctx = this.audioCtx;
      const now = ctx ? ctx.currentTime : 0;
      this.activeGainNodes.forEach(g => {
        try {
          if (ctx) {
            g.gain.cancelScheduledValues(now);
            g.gain.setValueAtTime(0.0001, now);
          }
          g.disconnect();
        } catch {
          // ignore
        }
      });
    } catch {
      // ignore
    }
    this.activeGainNodes = [];

    this.activeOscillators.forEach(osc => {
      try {
        osc.stop();
        osc.disconnect();
      } catch {
        // ignore
      }
    });
    this.activeOscillators = [];

    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(0);
      } catch {
        // ignore
      }
    }
  }

  /**
   * Discrete click sound for Tasbih button tap
   */
  public playTasbihClick() {
    try {
      const ctx = this.getContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(600, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(300, ctx.currentTime + 0.04);

      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.04);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.05);

      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        navigator.vibrate(15);
      }
    } catch {
      // ignore
    }
  }

  /**
   * Triumph chord on completing a Tasbih round or all prayers
   */
  public playTasbihComplete() {
    try {
      const ctx = this.getContext();
      const chord = [523.25, 659.25, 783.99, 1046.5]; // C Major
      chord.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.06);

        gain.gain.setValueAtTime(0.001, ctx.currentTime + idx * 0.06);
        gain.gain.exponentialRampToValueAtTime(0.2, ctx.currentTime + idx * 0.06 + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.06 + 0.9);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(ctx.currentTime + idx * 0.06);
        osc.stop(ctx.currentTime + idx * 0.06 + 0.95);
      });

      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        navigator.vibrate([60, 40, 80]);
      }
    } catch {
      // ignore
    }
  }

  /**
   * Request notification permission
   */
  public async requestNotificationPermission(): Promise<boolean> {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      if (Notification.permission === 'granted') return true;
      if (Notification.permission !== 'denied') {
        const status = await Notification.requestPermission();
        return status === 'granted';
      }
    }
    return false;
  }

  /**
   * Dispatch system notification
   */
  public dispatchNotification(title: string, body: string) {
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(title, {
          body,
          icon: '/favicon.ico',
          badge: '/favicon.ico',
          silent: false,
        });
      } catch (e) {
        console.warn('Notification error', e);
      }
    }
  }
}

export const soundService = new SoundService();
