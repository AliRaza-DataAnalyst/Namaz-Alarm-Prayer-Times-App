export type TabType = 'alarms' | 'namaz' | 'tasks' | 'tasbih' | 'qibla';

export interface AlarmItem {
  id: string;
  p?: string; // prayer name if standard prayer (e.g. Fajr, Zuhr, Asr, Maghrib, Isha, Tahajjud)
  t: string; // HH:mm in 24h format
  l: string; // Label (Urdu/English)
  on: boolean; // Is active
  d: number[]; // Days of week: 0=Sun, 1=Mon, 2=Tue, 3=Wed, 4=Thu, 5=Fri, 6=Sat
  sound?: 'native_tone' | 'melodic_azan' | 'soft_bell' | 'chime';
}

export interface TaskItem {
  id: string;
  n: string; // Task name
  t?: string; // Reminder time HH:mm
  x: boolean; // Completed
  fired?: string;
  createdAt?: number;
}

export interface TasbihState {
  n: number; // Current count
  goal: number; // Target per round (33, 99, 100, etc.)
  selectedDhikrId?: string;
  totalCount?: number;
}

export interface DhikrPreset {
  id: string;
  arabic: string;
  transliteration: string;
  urdu: string;
  meaning: string;
  defaultGoal: number;
}

export interface LocationConfig {
  city: string;
  country: string;
  latitude: number;
  longitude: number;
  isAuto: boolean;
}

export type CalculationMethodKey =
  | 'Karachi'
  | 'MWL'
  | 'ISNA'
  | 'UmmAlQura'
  | 'Egypt'
  | 'Dubai'
  | 'Qatar'
  | 'Kuwait'
  | 'Singapore'
  | 'Tehran';

export type MadhabKey = 'hanafi' | 'shafii';

export interface AppSettings {
  sound: 'native_tone' | 'melodic_azan' | 'soft_bell' | 'chime';
  volume: number;
  vibration: boolean;
  timeFormat24: boolean;
  calculationMethod: CalculationMethodKey;
  madhab: MadhabKey;
  location: LocationConfig;
  urduLabels: boolean;
  adhanAudioUrl?: string;
}

export interface PrayerTimeItem {
  key: string;
  name: string;
  urduName: string;
  arabicName: string;
  timeString: string;
  timeDate: Date;
  isPassed: boolean;
  isNext: boolean;
  alarmId?: string;
}

export interface DuaItem {
  id: string;
  title: string;
  urduTitle: string;
  arabic: string;
  transliteration: string;
  translation: string;
  urduTranslation: string;
  category: 'after_namaz' | 'morning_evening' | 'sleep' | 'protection' | 'forgiveness';
  reference: string;
}
