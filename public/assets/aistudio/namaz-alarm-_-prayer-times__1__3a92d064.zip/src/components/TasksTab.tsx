import React, { useState } from 'react';
import { TaskItem, AppSettings } from '../types';
import { formatDisplayTime, formatTime12 } from '../services/prayerService';
import { Plus, Check, X, Clock, Sparkles, Trash2 } from 'lucide-react';
import { soundService } from '../services/soundService';

interface TasksTabProps {
  tasks: TaskItem[];
  settings?: AppSettings;
  onUpdateTasks: (tasks: TaskItem[]) => void;
}

const ISLAMIC_SUGGESTIONS = [
  { name: '📖 Recite Surah Al-Kahf (Friday)', time: '11:00' },
  { name: '✨ Morning Adhkar & Ayat al-Kursi', time: '06:00' },
  { name: '🌙 Evening Adhkar before Maghrib', time: '17:30' },
  { name: '🛡️ Recite Surah Al-Mulk before sleep', time: '21:30' },
  { name: '📿 Read Durood Sharif 100 times', time: '14:00' },
  { name: '💧 Make Wudu before going to sleep', time: '22:00' },
];

export const TasksTab: React.FC<TasksTabProps> = ({ tasks, settings, onUpdateTasks }) => {
  const [taskName, setTaskName] = useState('');
  const [reminderTime, setReminderTime] = useState('');

  const openCount = tasks.filter(t => !t.x).length;
  const doneCount = tasks.filter(t => t.x).length;

  const handleAddTask = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const trimmed = taskName.trim();
    if (!trimmed) return;

    soundService.requestNotificationPermission();

    const newTask: TaskItem = {
      id: 't_' + Date.now(),
      n: trimmed,
      t: reminderTime || undefined,
      x: false,
      createdAt: Date.now(),
    };

    onUpdateTasks([newTask, ...tasks]);
    setTaskName('');
    setReminderTime('');
  };

  const handleAddSuggestion = (suggestion: { name: string; time: string }) => {
    const newTask: TaskItem = {
      id: 't_' + Date.now(),
      n: suggestion.name,
      t: suggestion.time,
      x: false,
      createdAt: Date.now(),
    };
    onUpdateTasks([newTask, ...tasks]);
  };

  const toggleTask = (id: string) => {
    const updated = tasks.map(t => {
      if (t.id === id) {
        if (!t.x) {
          soundService.playTasbihClick();
        }
        return { ...t, x: !t.x };
      }
      return t;
    });
    onUpdateTasks(updated);
  };

  const deleteTask = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = tasks.filter(t => t.id !== id);
    onUpdateTasks(updated);
  };

  const clearCompleted = () => {
    const updated = tasks.filter(t => !t.x);
    onUpdateTasks(updated);
  };

  return (
    <div className="pb-24 max-w-lg mx-auto space-y-4 px-4 pt-3">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-white">Daily Tasks</h2>
          <p className="text-xs text-zinc-400 mt-0.5">
            {openCount} to do • {doneCount} completed
          </p>
        </div>
        {doneCount > 0 && (
          <button
            onClick={clearCompleted}
            className="text-xs text-zinc-400 hover:text-red-400 transition-colors flex items-center gap-1 cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear done</span>
          </button>
        )}
      </div>

      {/* Add Task Input Form */}
      <form onSubmit={handleAddTask} className="flex gap-2">
        <input
          type="text"
          placeholder="New task / reminder..."
          maxLength={80}
          value={taskName}
          onChange={e => setTaskName(e.target.value)}
          className="flex-1 bg-[#1c1c1e] border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500 transition-colors"
        />
        <input
          type="time"
          value={reminderTime}
          onChange={e => setReminderTime(e.target.value)}
          title="Reminder time"
          className="w-28 bg-[#1c1c1e] border border-zinc-800 rounded-xl px-2 py-3 text-xs text-white text-center focus:outline-none focus:border-amber-500 transition-colors"
        />
        <button
          type="submit"
          className="px-4 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-semibold text-sm transition-all cursor-pointer shadow-lg shadow-amber-950/40 flex items-center justify-center shrink-0"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
        </button>
      </form>

      {/* Quick Islamic Suggestions */}
      <div className="space-y-1.5">
        <div className="text-[11px] font-semibold uppercase tracking-wider text-zinc-400 flex items-center gap-1">
          <Sparkles className="w-3 h-3 text-amber-400" />
          <span>Quick Islamic Reminders</span>
        </div>
        <div className="flex gap-1.5 overflow-x-auto pb-1.5 scrollbar-none text-xs">
          {ISLAMIC_SUGGESTIONS.map(s => (
            <button
              key={s.name}
              onClick={() => handleAddSuggestion(s)}
              className="px-3 py-1.5 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-amber-400 hover:border-amber-500/40 transition-all shrink-0 cursor-pointer text-xs"
            >
              + {s.name}
            </button>
          ))}
        </div>
      </div>

      {/* Task List */}
      <div className="rounded-3xl bg-[#1c1c1e] border border-zinc-800 divide-y divide-zinc-800/80 overflow-hidden shadow-lg">
        {tasks.length === 0 ? (
          <div className="text-center py-12 px-4 text-zinc-500 text-sm">
            Nothing to do yet. Add your first task or reminder above.
          </div>
        ) : (
          tasks.map(t => {
            const timeFormatted = t.t ? formatTime12(t.t) : null;
            return (
              <div
                key={t.id}
                onClick={() => toggleTask(t.id)}
                className={`p-3.5 flex items-center gap-3 transition-colors hover:bg-zinc-800/30 cursor-pointer ${
                  t.x ? 'opacity-50' : 'opacity-100'
                }`}
              >
                {/* Checkbox button */}
                <button
                  type="button"
                  onClick={e => {
                    e.stopPropagation();
                    toggleTask(t.id);
                  }}
                  className={`w-6 h-6 rounded-full flex items-center justify-center transition-all cursor-pointer shrink-0 ${
                    t.x
                      ? 'bg-emerald-500 text-black'
                      : 'border-2 border-zinc-600 hover:border-zinc-400 bg-transparent'
                  }`}
                  aria-label="Toggle task completion"
                >
                  {t.x && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                </button>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div
                    className={`text-sm font-medium transition-colors break-words ${
                      t.x ? 'line-through text-zinc-400' : 'text-white'
                    }`}
                  >
                    {t.n}
                  </div>
                  {t.t && (
                    <div className="flex items-center gap-1 text-[11px] text-amber-400 font-mono mt-0.5">
                      <Clock className="w-3 h-3" />
                      <span>Reminder {formatDisplayTime(t.t, settings?.timeFormat24)}</span>
                    </div>
                  )}
                </div>

                {/* Delete button */}
                <button
                  onClick={e => deleteTask(t.id, e)}
                  title="Delete task"
                  className="p-1.5 rounded-lg text-zinc-500 hover:text-red-400 hover:bg-red-500/10 transition-colors shrink-0"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
