import React, { useState } from 'react';
import { TasbihState } from '../types';
import { DHIKR_PRESETS } from '../data/dhikrAndDuas';
import { RotateCcw, Volume2, Sparkles, Check } from 'lucide-react';
import { soundService } from '../services/soundService';
import confetti from 'canvas-confetti';

interface TasbihTabProps {
  tasbih: TasbihState;
  onUpdateTasbih: (tasbih: TasbihState) => void;
}

export const TasbihTab: React.FC<TasbihTabProps> = ({ tasbih, onUpdateTasbih }) => {
  const [soundEnabled, setSoundEnabled] = useState(true);

  const selectedDhikr =
    DHIKR_PRESETS.find(d => d.id === tasbih.selectedDhikrId) || DHIKR_PRESETS[0];

  const handleTap = () => {
    const nextN = tasbih.n + 1;
    const isGoalReached = nextN > 0 && nextN % tasbih.goal === 0;

    if (soundEnabled) {
      if (isGoalReached) {
        soundService.playTasbihComplete();
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.7 },
          colors: ['#34c759', '#ff9f0a', '#ffffff'],
        });
      } else {
        soundService.playTasbihClick();
      }
    } else {
      // Haptic vibration only
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        navigator.vibrate(isGoalReached ? [80, 60, 80] : 15);
      }
    }

    onUpdateTasbih({
      ...tasbih,
      n: nextN,
      totalCount: (tasbih.totalCount || 0) + 1,
    });
  };

  const handleSetGoal = (goal: number) => {
    soundService.playTasbihClick();
    onUpdateTasbih({ ...tasbih, goal });
  };

  const handleSelectDhikr = (id: string) => {
    soundService.playTasbihClick();
    const preset = DHIKR_PRESETS.find(d => d.id === id);
    onUpdateTasbih({
      ...tasbih,
      selectedDhikrId: id,
      goal: preset?.defaultGoal || tasbih.goal,
    });
  };

  const [confirmReset, setConfirmReset] = useState(false);

  const performReset = () => {
    soundService.playTasbihClick();
    onUpdateTasbih({
      ...tasbih,
      n: 0,
      totalCount: 0,
    });
    setConfirmReset(false);
  };

  const rounds = Math.floor(tasbih.n / tasbih.goal);
  const currentLap = tasbih.n % tasbih.goal;
  const displayLap = tasbih.n > 0 && currentLap === 0 ? tasbih.goal : currentLap;
  const progressPct = Math.min(100, Math.round((displayLap / tasbih.goal) * 100));

  // Circular progress ring calculation
  const radius = 95;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progressPct / 100) * circumference;

  return (
    <div className="pb-24 max-w-lg mx-auto space-y-4 px-4 pt-3 flex flex-col items-center">
      {/* Header */}
      <div className="w-full flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <span>Digital Tasbih</span>
            <span className="text-base">📿</span>
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5">Dhikr counter & remembrance</p>
        </div>
        <button
          onClick={() => setSoundEnabled(!soundEnabled)}
          className={`p-2 rounded-xl border transition-all cursor-pointer ${
            soundEnabled
              ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
              : 'bg-zinc-900 text-zinc-500 border-zinc-800'
          }`}
          title="Toggle audio click"
        >
          <Volume2 className="w-4 h-4" />
        </button>
      </div>

      {/* Dhikr Preset Carousel */}
      <div className="w-full overflow-x-auto pb-1 scrollbar-none flex gap-2">
        {DHIKR_PRESETS.map(preset => {
          const isSelected = preset.id === selectedDhikr.id;
          return (
            <button
              key={preset.id}
              onClick={() => handleSelectDhikr(preset.id)}
              className={`px-3 py-2 rounded-2xl border text-left shrink-0 transition-all cursor-pointer ${
                isSelected
                  ? 'bg-emerald-950/40 border-emerald-500/50 text-white shadow-md'
                  : 'bg-[#1c1c1e] border-zinc-800 text-zinc-400 hover:text-white'
              }`}
            >
              <div className="text-sm font-arabic font-bold leading-tight">
                {preset.arabic}
              </div>
              <div className="text-[10px] text-zinc-400 mt-0.5 truncate max-w-[130px]">
                {preset.transliteration}
              </div>
            </button>
          );
        })}
      </div>

      {/* Selected Dhikr Display Card */}
      <div className="w-full rounded-2xl bg-[#1c1c1e] border border-zinc-800 p-4 text-center space-y-1 shadow-lg">
        <div className="text-2xl sm:text-3xl font-arabic font-bold text-amber-400 leading-normal">
          {selectedDhikr.arabic}
        </div>
        <div className="text-xs text-zinc-400 font-medium">
          {selectedDhikr.transliteration} • <span className="font-urdu text-zinc-300">{selectedDhikr.urdu}</span>
        </div>
        <div className="text-[11px] text-zinc-500">
          "{selectedDhikr.meaning}"
        </div>
      </div>

      {/* Big Tactile Counter Button with Circular Progress Ring */}
      <div className="relative my-4 flex items-center justify-center select-none">
        {/* SVG Progress Ring */}
        <svg className="w-64 h-64 sm:w-72 sm:h-72 -rotate-90 pointer-events-none">
          <circle
            cx="50%"
            cy="50%"
            r={radius}
            stroke="#27272a"
            strokeWidth="10"
            fill="transparent"
          />
          <circle
            cx="50%"
            cy="50%"
            r={radius}
            stroke="#34c759"
            strokeWidth="10"
            fill="transparent"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            className="transition-all duration-200"
          />
        </svg>

        {/* Center Circular Button */}
        <button
          onClick={handleTap}
          className="absolute w-44 h-44 sm:w-48 sm:h-48 rounded-full bg-gradient-to-tr from-[#143d22] to-[#2f7d46] hover:from-[#1a4f2c] hover:to-[#388e52] active:scale-95 border-4 border-[#34c759] shadow-2xl shadow-emerald-950/80 flex flex-col items-center justify-center text-white transition-transform duration-100 cursor-pointer"
        >
          <span className="text-5xl sm:text-6xl font-light font-mono tracking-tight">
            {tasbih.n}
          </span>
          <span className="text-[11px] font-semibold text-emerald-200 uppercase tracking-widest mt-1 opacity-80">
            TAP TO COUNT
          </span>
        </button>
      </div>

      {/* Goal Selector Chips */}
      <div className="w-full flex items-center gap-2">
        {[33, 99, 100].map(g => (
          <button
            key={g}
            onClick={() => handleSetGoal(g)}
            className={`flex-1 py-2.5 rounded-2xl font-semibold text-sm transition-all cursor-pointer ${
              tasbih.goal === g
                ? 'bg-amber-500 text-black shadow-md shadow-amber-950/40'
                : 'bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-white'
            }`}
          >
            Goal {g}
          </button>
        ))}
      </div>

      {/* Stats Summary Card */}
      <div className="w-full rounded-2xl bg-[#1c1c1e] border border-zinc-800 p-3.5 flex items-center justify-around text-center text-xs">
        <div>
          <div className="text-zinc-500">Lap Progress</div>
          <div className="text-white font-mono font-bold text-sm mt-0.5">
            {displayLap} / {tasbih.goal}
          </div>
        </div>
        <div className="w-px h-8 bg-zinc-800" />
        <div>
          <div className="text-zinc-500">Rounds Done</div>
          <div className="text-emerald-400 font-mono font-bold text-sm mt-0.5">
            {rounds}
          </div>
        </div>
        <div className="w-px h-8 bg-zinc-800" />
        <div>
          <div className="text-zinc-500">Total Count</div>
          <div className="text-amber-400 font-mono font-bold text-sm mt-0.5">
            {tasbih.totalCount !== undefined ? tasbih.totalCount : tasbih.n}
          </div>
        </div>
      </div>

      {/* Reset Button with Inline Confirmation (No window.confirm) */}
      {confirmReset ? (
        <div className="w-full p-3.5 rounded-2xl bg-zinc-900 border border-red-500/40 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-lg">
          <div className="text-xs text-zinc-300 font-medium text-center sm:text-left">
            Reset Tasbih counter to 0?
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={() => setConfirmReset(false)}
              className="flex-1 sm:flex-none px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold cursor-pointer transition-colors"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={performReset}
              className="flex-1 sm:flex-none px-4 py-2 rounded-xl bg-red-500 hover:bg-red-400 text-white text-xs font-semibold shadow-md shadow-red-950/50 cursor-pointer flex items-center justify-center gap-1.5 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Yes, Reset to 0</span>
            </button>
          </div>
        </div>
      ) : (
        <button
          type="button"
          onClick={() => {
            const isZero = tasbih.n === 0 && (tasbih.totalCount || 0) === 0;
            if (isZero) return;
            setConfirmReset(true);
          }}
          disabled={tasbih.n === 0 && (tasbih.totalCount || 0) === 0}
          className={`w-full py-3.5 rounded-2xl border text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer ${
            tasbih.n === 0 && (tasbih.totalCount || 0) === 0
              ? 'bg-zinc-900/40 border-zinc-800/40 text-zinc-600 cursor-not-allowed'
              : 'bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white border-zinc-800 shadow-md active:scale-98'
          }`}
        >
          <RotateCcw className="w-3.5 h-3.5 text-zinc-400" />
          <span>
            {tasbih.n === 0 && (tasbih.totalCount || 0) === 0
              ? 'Counter is at 0'
              : 'Reset Counter to 0'}
          </span>
        </button>
      )}
    </div>
  );
};
