import React, { useEffect, useState, useRef } from 'react';
import { AppSettings } from '../types';
import { calculateQiblaDirection } from '../services/prayerService';
import { Compass, MapPin, Navigation as NavIcon, Info, RotateCcw } from 'lucide-react';
import { soundService } from '../services/soundService';

interface QiblaTabProps {
  settings: AppSettings;
  onOpenSettings: () => void;
}

export const QiblaTab: React.FC<QiblaTabProps> = ({ settings, onOpenSettings }) => {
  const [deviceHeading, setDeviceHeading] = useState<number | null>(null);
  const [manualOffset, setManualOffset] = useState<number>(0);
  const [hasSensor, setHasSensor] = useState<boolean>(false);
  const [permissionRequested, setPermissionRequested] = useState<boolean>(false);

  // References for shortest-arc continuous rotation
  const prevHeadingRef = useRef<number>(0);
  const continuousHeadingRef = useRef<number>(0);
  const prevAngleRef = useRef<number>(0);
  const continuousAngleRef = useRef<number>(0);

  const { bearing: qiblaBearing, distanceKm } = calculateQiblaDirection(
    settings.location.latitude,
    settings.location.longitude
  );

  // Listen to device orientation for true compass heading
  useEffect(() => {
    const handleOrientation = (e: DeviceOrientationEvent) => {
      let heading: number | null = null;

      // webkitCompassHeading on iOS
      if ('webkitCompassHeading' in e && typeof (e as unknown as { webkitCompassHeading?: number }).webkitCompassHeading === 'number') {
        heading = (e as unknown as { webkitCompassHeading: number }).webkitCompassHeading;
      } else if (e.alpha !== null) {
        // Android fallback (alpha represents rotation around z axis)
        heading = (360 - e.alpha) % 360;
      }

      if (heading !== null && !isNaN(heading)) {
        setDeviceHeading(Math.round(heading));
        setHasSensor(true);
      }
    };

    if (typeof window !== 'undefined' && 'DeviceOrientationEvent' in window) {
      window.addEventListener('deviceorientation', handleOrientation, true);
      // also check deviceorientationabsolute for Chrome Android
      window.addEventListener('deviceorientationabsolute', handleOrientation as EventListener, true);
    }

    return () => {
      if (typeof window !== 'undefined' && 'DeviceOrientationEvent' in window) {
        window.removeEventListener('deviceorientation', handleOrientation, true);
        window.removeEventListener('deviceorientationabsolute', handleOrientation as EventListener, true);
      }
    };
  }, []);

  const requestIosCompassPermission = async () => {
    setPermissionRequested(true);
    if (
      typeof DeviceOrientationEvent !== 'undefined' &&
      typeof (DeviceOrientationEvent as unknown as { requestPermission?: () => Promise<string> }).requestPermission === 'function'
    ) {
      try {
        const response = await (DeviceOrientationEvent as unknown as { requestPermission: () => Promise<string> }).requestPermission();
        if (response === 'granted') {
          soundService.playTasbihClick();
        }
      } catch (e) {
        console.warn('iOS orientation permission error', e);
      }
    }
  };

  // Effective user heading (either from device sensor or manual slider)
  const currentHeading = deviceHeading !== null ? deviceHeading : manualOffset;

  // Track continuous heading for seamless dial rotation
  const headingDiff = ((currentHeading - (prevHeadingRef.current % 360) + 540) % 360) - 180;
  continuousHeadingRef.current += headingDiff;
  prevHeadingRef.current = currentHeading;

  // Relative angle to Kaaba from user's current facing direction
  // Needle points to (qiblaBearing - currentHeading)
  const relativeAngle = ((qiblaBearing - currentHeading) % 360 + 360) % 360;

  // Track continuous angle for needle so it doesn't spin 360 degrees when crossing 0
  const angleDiff = ((relativeAngle - (prevAngleRef.current % 360) + 540) % 360) - 180;
  continuousAngleRef.current += angleDiff;
  prevAngleRef.current = relativeAngle;

  // Is aligned with Kaaba within +/- 4 degrees?
  const isAligned = relativeAngle <= 4 || relativeAngle >= 356;

  // Cardinal directions for compass rose
  const cardinals = [
    { label: 'N', deg: 0, bold: true },
    { label: 'E', deg: 90 },
    { label: 'S', deg: 180 },
    { label: 'W', deg: 270 },
  ];

  return (
    <div className="pb-24 max-w-lg mx-auto space-y-4 px-4 pt-3">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <span>Qibla Compass</span>
            <span>🕋</span>
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5">
            Pointing towards the Holy Kaaba in Makkah
          </p>
        </div>
        <button
          onClick={onOpenSettings}
          className="flex items-center gap-1 text-xs text-zinc-400 hover:text-emerald-400 bg-zinc-900 border border-zinc-800 px-3 py-1.5 rounded-xl cursor-pointer"
        >
          <MapPin className="w-3.5 h-3.5 text-emerald-400" />
          <span>{settings.location.city}</span>
        </button>
      </div>

      {/* Alignment Status Banner */}
      <div
        className={`p-3.5 rounded-2xl border transition-all text-center flex items-center justify-center gap-2 ${
          isAligned
            ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 shadow-lg shadow-emerald-950/50'
            : 'bg-zinc-900 border-zinc-800 text-zinc-300'
        }`}
      >
        <div className={`w-3 h-3 rounded-full ${isAligned ? 'bg-emerald-400 animate-ping' : 'bg-amber-400'}`} />
        <span className="font-semibold text-sm">
          {isAligned ? '✨ You are facing the Qibla (Makkah)!' : `Turn ${Math.round(relativeAngle > 180 ? 360 - relativeAngle : relativeAngle)}° ${relativeAngle > 180 ? 'left' : 'right'} to face Qibla`}
        </span>
      </div>

      {/* Compass Interactive Dial */}
      <div className="rounded-3xl bg-[#1c1c1e] border border-zinc-800 p-6 flex flex-col items-center justify-center shadow-xl relative overflow-hidden">
        {/* Distance Badge */}
        <div className="absolute top-4 left-4 text-[11px] text-zinc-400 flex items-center gap-1">
          <span>Distance:</span>
          <span className="font-mono font-semibold text-white">{distanceKm.toLocaleString()} km</span>
        </div>

        {/* Qibla Bearing Badge */}
        <div className="absolute top-4 right-4 text-[11px] text-zinc-400 flex items-center gap-1">
          <span>Bearing:</span>
          <span className="font-mono font-semibold text-amber-400">{qiblaBearing}°</span>
        </div>

        {/* Outer Circular Dial */}
        <div className="relative w-64 h-64 sm:w-72 sm:h-72 my-4 flex items-center justify-center select-none">
          {/* Compass ring with degree ticks */}
          <div
            className="absolute inset-0 rounded-full border-4 border-zinc-800/80 bg-zinc-950/60 shadow-inner transition-transform duration-200"
            style={{
              transform: `rotate(${-continuousHeadingRef.current}deg)`,
            }}
          >
            {/* Degree ticks */}
            {Array.from({ length: 36 }).map((_, i) => (
              <div
                key={i}
                className="absolute top-0 left-1/2 -translate-x-1/2 w-0.5 origin-bottom"
                style={{
                  height: i % 3 === 0 ? '12px' : '6px',
                  backgroundColor: i % 9 === 0 ? '#ff9f0a' : i % 3 === 0 ? '#71717a' : '#3f3f46',
                  transform: `rotate(${i * 10}deg)`,
                  transformOrigin: '50% 128px',
                }}
              />
            ))}

            {/* Cardinals N, E, S, W */}
            {cardinals.map(c => (
              <div
                key={c.label}
                className="absolute text-xs font-bold"
                style={{
                  top: c.deg === 0 ? '16px' : c.deg === 180 ? 'calc(100% - 28px)' : 'calc(50% - 8px)',
                  left: c.deg === 270 ? '16px' : c.deg === 90 ? 'calc(100% - 24px)' : 'calc(50% - 6px)',
                  color: c.deg === 0 ? '#ef4444' : '#a1a1aa',
                }}
              >
                {c.label}
              </div>
            ))}
          </div>

          {/* Kaaba Direction Needle */}
          <div
            className="absolute inset-0 flex items-center justify-center transition-transform duration-300"
            style={{
              transform: `rotate(${continuousAngleRef.current}deg)`,
            }}
          >
            {/* Needle pointing UP towards Kaaba */}
            <div className="relative w-12 h-56 flex flex-col items-center justify-between pointer-events-none">
              {/* Kaaba Icon at the tip */}
              <div className="flex flex-col items-center">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-b from-amber-400 to-amber-600 border border-amber-200 shadow-lg shadow-amber-500/50 flex items-center justify-center text-lg animate-bounce">
                  🕋
                </div>
                <div className="w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-t-[10px] border-t-amber-500 -mt-0.5" />
              </div>

              {/* Center Pivot Point */}
              <div className="w-6 h-6 rounded-full bg-zinc-900 border-2 border-emerald-400 shadow-md flex items-center justify-center z-10">
                <div className="w-2 h-2 rounded-full bg-emerald-400" />
              </div>

              {/* Bottom counter-weight */}
              <div className="w-2.5 h-12 bg-zinc-700/60 rounded-full" />
            </div>
          </div>

          {/* Heading overlay in center */}
          <div className="absolute flex flex-col items-center pointer-events-none mt-20">
            <span className="text-2xl font-bold font-mono text-white leading-none">
              {Math.round(currentHeading)}°
            </span>
            <span className="text-[10px] font-semibold text-zinc-400 tracking-wider uppercase mt-0.5">
              Current Heading
            </span>
          </div>
        </div>

        {/* Sensor info or iOS permission button */}
        {!hasSensor && (
          <div className="w-full mt-2 pt-3 border-t border-zinc-800 text-center">
            <p className="text-xs text-zinc-400 mb-2">
              Sensor not detected or on desktop. Use slider below to align compass:
            </p>
            <div className="flex items-center gap-3">
              <span className="text-xs font-mono text-zinc-500">0°</span>
              <input
                type="range"
                min="0"
                max="359"
                value={manualOffset}
                onChange={e => setManualOffset(Number(e.target.value))}
                className="flex-1 accent-amber-500 h-2 bg-zinc-800 rounded-lg cursor-pointer"
              />
              <span className="text-xs font-mono text-zinc-500">359°</span>
            </div>

            <button
              onClick={requestIosCompassPermission}
              className="mt-3 px-3 py-1.5 rounded-xl bg-zinc-800 text-zinc-300 text-xs hover:text-white cursor-pointer"
            >
              Calibrate / Request iOS Sensor
            </button>
          </div>
        )}

        {hasSensor && (
          <div className="flex items-center gap-1.5 text-xs text-emerald-400 mt-2">
            <NavIcon className="w-3.5 h-3.5 animate-spin" />
            <span>Live Device Compass Active</span>
          </div>
        )}
      </div>

      {/* Info Card */}
      <div className="rounded-2xl bg-[#1c1c1e] border border-zinc-800 p-4 text-xs text-zinc-400 space-y-2">
        <div className="flex items-center gap-1.5 text-zinc-200 font-semibold">
          <Info className="w-4 h-4 text-amber-400" />
          <span>Accurate Qibla Guidance</span>
        </div>
        <p className="leading-relaxed">
          The Qibla is the direction of the Kaaba in the Sacred Mosque (Masjid al-Haram) in Makkah, Saudi Arabia. For best accuracy on phones, hold your device flat and move it in a figure-8 motion to calibrate the magnetometer.
        </p>
      </div>
    </div>
  );
};
