import React, { useState } from 'react';
import { AppSettings, CalculationMethodKey, MadhabKey } from '../types';
import { POPULAR_CITIES } from '../services/prayerService';
import { soundService } from '../services/soundService';
import {
  X,
  MapPin,
  Compass,
  Volume2,
  Download,
  Smartphone,
  Check,
  Play,
  Square,
  Sparkles,
} from 'lucide-react';

interface SettingsModalProps {
  settings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  onClose: () => void;
}

const CALC_METHODS: { key: CalculationMethodKey; label: string; desc: string }[] = [
  { key: 'Karachi', label: 'University of Islamic Sciences, Karachi', desc: 'Fajr 18°, Isha 18° (Pakistan, India, Bangladesh)' },
  { key: 'MWL', label: 'Muslim World League (MWL)', desc: 'Fajr 18°, Isha 17° (Europe, Far East)' },
  { key: 'ISNA', label: 'Islamic Society of North America (ISNA)', desc: 'Fajr 15°, Isha 15° (USA, Canada)' },
  { key: 'UmmAlQura', label: 'Umm al-Qura University, Makkah', desc: 'Fajr 18.5°, Isha 90min after Maghrib (Saudi Arabia)' },
  { key: 'Egypt', label: 'Egyptian General Authority of Survey', desc: 'Fajr 19.5°, Isha 17.5° (Africa, Middle East)' },
  { key: 'Dubai', label: 'Dubai / UAE Awqaf', desc: 'Official UAE timings' },
  { key: 'Qatar', label: 'Qatar Ministry of Awqaf', desc: 'Official Qatar timings' },
  { key: 'Kuwait', label: 'Kuwait Ministry of Awqaf', desc: 'Official Kuwait timings' },
  { key: 'Singapore', label: 'MUIS Singapore', desc: 'Singapore official timings' },
  { key: 'Tehran', label: 'Institute of Geophysics, Tehran', desc: 'Fajr 17.7°, Isha 14°' },
];

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  onUpdateSettings,
  onClose,
}) => {
  const [localSettings, setLocalSettings] = useState<AppSettings>({ ...settings });
  const [isLocating, setIsLocating] = useState(false);
  const [previewingSound, setPreviewingSound] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const handleSoundPreview = (soundKey: 'native_tone' | 'melodic_azan' | 'soft_bell' | 'chime') => {
    if (previewingSound === soundKey) {
      soundService.stopAlarm();
      setPreviewingSound(null);
    } else {
      setPreviewingSound(soundKey);
      soundService.startAlarmLoop(soundKey, localSettings.volume);
    }
  };

  const handleStopPreview = () => {
    soundService.stopAlarm();
    setPreviewingSound(null);
  };

  const handleDetectGPS = () => {
    if (!navigator.geolocation) {
      setStatusMessage('Geolocation is not supported by your browser.');
      setTimeout(() => setStatusMessage(null), 4000);
      return;
    }

    setIsLocating(true);
    setStatusMessage(null);
    navigator.geolocation.getCurrentPosition(
      pos => {
        setIsLocating(false);
        const lat = Math.round(pos.coords.latitude * 10000) / 10000;
        const lng = Math.round(pos.coords.longitude * 10000) / 10000;

        setLocalSettings(prev => ({
          ...prev,
          location: {
            city: 'My Location',
            country: 'GPS Detected',
            latitude: lat,
            longitude: lng,
            isAuto: true,
          },
        }));
        setStatusMessage('GPS location detected successfully!');
        setTimeout(() => setStatusMessage(null), 3500);
      },
      err => {
        setIsLocating(false);
        setStatusMessage('Could not retrieve GPS location: ' + err.message);
        setTimeout(() => setStatusMessage(null), 4500);
      },
      { timeout: 10000, enableHighAccuracy: true }
    );
  };

  const handleSelectCity = (cityName: string) => {
    const found = POPULAR_CITIES.find(c => c.city === cityName);
    if (found) {
      setLocalSettings(prev => ({
        ...prev,
        location: {
          city: found.city,
          country: found.country,
          latitude: found.latitude,
          longitude: found.longitude,
          isAuto: false,
        },
      }));
    }
  };

  const handleSave = () => {
    handleStopPreview();
    onUpdateSettings(localSettings);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="w-full max-w-xl max-h-[92vh] bg-[#1c1c1e] border-t sm:border border-zinc-800 rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-zinc-800 flex items-center justify-between shrink-0">
          <div>
            <h3 className="text-base font-bold text-white">Settings & Calculation</h3>
            <p className="text-[11px] text-zinc-400">Prayer calculations, sound tone, and native app</p>
          </div>
          <button
            onClick={() => {
              handleStopPreview();
              onClose();
            }}
            className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-6 flex-1 text-sm">
          {/* Section 1: Location */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5" />
                <span>Location & Coordinates</span>
              </label>
              <button
                type="button"
                onClick={handleDetectGPS}
                disabled={isLocating}
                className="text-xs text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1 cursor-pointer disabled:opacity-50"
              >
                <Compass className={`w-3.5 h-3.5 ${isLocating ? 'animate-spin' : ''}`} />
                <span>{isLocating ? 'Locating...' : 'Auto GPS'}</span>
              </button>
            </div>

            {statusMessage && (
              <div className="px-3 py-2 rounded-xl bg-zinc-800 text-xs text-amber-300 border border-zinc-700 animate-in fade-in">
                {statusMessage}
              </div>
            )}

            {/* City Preset Dropdown */}
            <div>
              <label className="text-[11px] text-zinc-400 mb-1 block">Select City</label>
              <select
                value={localSettings.location.city}
                onChange={e => handleSelectCity(e.target.value)}
                className="w-full bg-[#2c2c2e] border border-zinc-700 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
              >
                {POPULAR_CITIES.map(c => (
                  <option key={c.city} value={c.city}>
                    {c.city}, {c.country} ({Math.abs(c.latitude)}°{c.latitude >= 0 ? 'N' : 'S'}, {Math.abs(c.longitude)}°{c.longitude >= 0 ? 'E' : 'W'})
                  </option>
                ))}
                {localSettings.location.isAuto && (
                  <option value="My Location">My Location (GPS Detected)</option>
                )}
              </select>
            </div>

            {/* Coordinate inputs */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <label className="text-[11px] text-zinc-500 mb-1 block">Latitude</label>
                <input
                  type="number"
                  step="any"
                  value={localSettings.location.latitude}
                  onChange={e =>
                    setLocalSettings(prev => ({
                      ...prev,
                      location: { ...prev.location, latitude: parseFloat(e.target.value) || 0 },
                    }))
                  }
                  className="w-full bg-[#2c2c2e] border border-zinc-800 rounded-xl px-3 py-2 text-white font-mono"
                />
              </div>
              <div>
                <label className="text-[11px] text-zinc-500 mb-1 block">Longitude</label>
                <input
                  type="number"
                  step="any"
                  value={localSettings.location.longitude}
                  onChange={e =>
                    setLocalSettings(prev => ({
                      ...prev,
                      location: { ...prev.location, longitude: parseFloat(e.target.value) || 0 },
                    }))
                  }
                  className="w-full bg-[#2c2c2e] border border-zinc-800 rounded-xl px-3 py-2 text-white font-mono"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Calculation Method */}
          <div className="space-y-3 pt-3 border-t border-zinc-800">
            <label className="text-xs font-bold uppercase tracking-wider text-amber-400 block">
              Islamic Calculation Method
            </label>
            <select
              value={localSettings.calculationMethod}
              onChange={e =>
                setLocalSettings(prev => ({
                  ...prev,
                  calculationMethod: e.target.value as CalculationMethodKey,
                }))
              }
              className="w-full bg-[#2c2c2e] border border-zinc-700 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
            >
              {CALC_METHODS.map(m => (
                <option key={m.key} value={m.key}>
                  {m.label}
                </option>
              ))}
            </select>
            <p className="text-[11px] text-zinc-500 leading-relaxed">
              {CALC_METHODS.find(m => m.key === localSettings.calculationMethod)?.desc}
            </p>
          </div>

          {/* Section 3: Juristic School (Asr Time) */}
          <div className="space-y-3 pt-3 border-t border-zinc-800">
            <label className="text-xs font-bold uppercase tracking-wider text-amber-400 block">
              Asr Prayer Juristic Method (Madhab)
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setLocalSettings(prev => ({ ...prev, madhab: 'hanafi' }))}
                className={`p-3 rounded-2xl border text-left cursor-pointer transition-all ${
                  localSettings.madhab === 'hanafi'
                    ? 'bg-emerald-500/20 border-emerald-500 text-white'
                    : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
                }`}
              >
                <div className="font-semibold text-xs text-white">Hanafi</div>
                <div className="text-[10px] text-zinc-400 mt-0.5">
                  Shadow factor 2 (Later Asr time - Pakistan, India, Turkey)
                </div>
              </button>

              <button
                type="button"
                onClick={() => setLocalSettings(prev => ({ ...prev, madhab: 'shafii' }))}
                className={`p-3 rounded-2xl border text-left cursor-pointer transition-all ${
                  localSettings.madhab === 'shafii'
                    ? 'bg-emerald-500/20 border-emerald-500 text-white'
                    : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
                }`}
              >
                <div className="font-semibold text-xs text-white">Standard / Shafi'i</div>
                <div className="text-[10px] text-zinc-400 mt-0.5">
                  Shadow factor 1 (Maliki, Shafi'i, Hanbali - Arab world)
                </div>
              </button>
            </div>
          </div>

          {/* Section 4: Alarm Sound Tone */}
          <div className="space-y-3 pt-3 border-t border-zinc-800">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                <Volume2 className="w-3.5 h-3.5" />
                <span>Alarm Sound Tone</span>
              </label>
              {previewingSound && (
                <button
                  onClick={handleStopPreview}
                  className="text-xs text-red-400 hover:text-red-300 flex items-center gap-1 cursor-pointer font-semibold"
                >
                  <Square className="w-3 h-3 fill-current" />
                  <span>Stop Preview</span>
                </button>
              )}
            </div>

            <div className="grid grid-cols-2 gap-2">
              {[
                { key: 'native_tone', label: 'Android CDMA Guard', desc: 'Original tone from native app' },
                { key: 'melodic_azan', label: 'Melodic Azan Call', desc: 'Peaceful Islamic harmonic notes' },
                { key: 'soft_bell', label: 'Soft Bell Chime', desc: 'Gentle meditation chime' },
                { key: 'chime', label: 'Crisp Double Chime', desc: 'Clear melodic prompt' },
              ].map(s => {
                const isSelected = localSettings.sound === s.key;
                const isPlaying = previewingSound === s.key;
                return (
                  <div
                    key={s.key}
                    onClick={() =>
                      setLocalSettings(prev => ({
                        ...prev,
                        sound: s.key as AppSettings['sound'],
                      }))
                    }
                    className={`p-3 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between ${
                      isSelected
                        ? 'bg-amber-500/15 border-amber-500 text-white'
                        : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
                    }`}
                  >
                    <div>
                      <div className="font-semibold text-xs text-white flex items-center justify-between">
                        <span>{s.label}</span>
                        {isSelected && <Check className="w-3.5 h-3.5 text-amber-400" />}
                      </div>
                      <div className="text-[10px] text-zinc-400 mt-0.5">{s.desc}</div>
                    </div>

                    <button
                      type="button"
                      onClick={e => {
                        e.stopPropagation();
                        handleSoundPreview(s.key as AppSettings['sound']);
                      }}
                      className="mt-2 text-[11px] text-amber-400 hover:text-amber-300 flex items-center gap-1 font-medium cursor-pointer"
                    >
                      {isPlaying ? (
                        <>
                          <Square className="w-3 h-3 fill-current text-red-400" />
                          <span className="text-red-400">Stop</span>
                        </>
                      ) : (
                        <>
                          <Play className="w-3 h-3 fill-current" />
                          <span>Preview</span>
                        </>
                      )}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Section 5: Volume & Device Preferences */}
          <div className="space-y-4 pt-3 border-t border-zinc-800">
            <label className="text-xs font-bold uppercase tracking-wider text-amber-400 block">
              Volume & Display Preferences
            </label>

            {/* Volume Slider */}
            <div className="p-3.5 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-zinc-300 font-medium flex items-center gap-1.5">
                  <Volume2 className="w-3.5 h-3.5 text-amber-400" />
                  <span>Alarm Volume</span>
                </span>
                <span className="font-mono text-amber-400 font-semibold">
                  {Math.round(localSettings.volume * 100)}%
                </span>
              </div>
              <input
                type="range"
                min="0.1"
                max="1"
                step="0.05"
                value={localSettings.volume}
                onChange={e => setLocalSettings(prev => ({ ...prev, volume: parseFloat(e.target.value) }))}
                className="w-full accent-amber-500 h-2 bg-zinc-800 rounded-lg cursor-pointer"
              />
            </div>

            {/* Toggles */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {/* Vibration Toggle */}
              <div
                onClick={() => setLocalSettings(prev => ({ ...prev, vibration: !prev.vibration }))}
                className="p-3 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-between cursor-pointer hover:bg-zinc-800 transition-colors"
              >
                <div>
                  <div className="text-xs font-semibold text-white">Vibrate on Alarm</div>
                  <div className="text-[10px] text-zinc-400">Haptic vibration pattern</div>
                </div>
                <div className={`w-10 h-6 rounded-full p-0.5 transition-colors ${localSettings.vibration ? 'bg-emerald-500' : 'bg-zinc-700'}`}>
                  <div className={`w-5 h-5 rounded-full bg-white transition-transform ${localSettings.vibration ? 'translate-x-4' : 'translate-x-0'}`} />
                </div>
              </div>

              {/* Time Format Toggle (12h vs 24h) */}
              <div
                onClick={() => setLocalSettings(prev => ({ ...prev, timeFormat24: !prev.timeFormat24 }))}
                className="p-3 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-between cursor-pointer hover:bg-zinc-800 transition-colors"
              >
                <div>
                  <div className="text-xs font-semibold text-white">Time Format</div>
                  <div className="text-[10px] text-zinc-400">
                    {localSettings.timeFormat24 ? '24-Hour (18:00)' : '12-Hour (6:00 PM)'}
                  </div>
                </div>
                <div className={`w-10 h-6 rounded-full p-0.5 transition-colors ${localSettings.timeFormat24 ? 'bg-amber-500' : 'bg-zinc-700'}`}>
                  <div className={`w-5 h-5 rounded-full bg-white transition-transform ${localSettings.timeFormat24 ? 'translate-x-4' : 'translate-x-0'}`} />
                </div>
              </div>
            </div>
          </div>

          {/* Section 6: Native Android Project & APK */}
          <div className="rounded-2xl bg-zinc-900/90 border border-zinc-800 p-4 space-y-3 pt-3">
            <div className="flex items-center gap-2 text-white font-semibold text-xs">
              <Smartphone className="w-4 h-4 text-emerald-400" />
              <span>Native Android App Project</span>
            </div>
            <p className="text-xs text-zinc-400 leading-relaxed">
              This web app originates from the attached Android project with native AlarmManager alarms, WakeLock, and foreground service. You can download the source zip to compile in Android Studio anytime:
            </p>
            <a
              href="/assets/aistudio/NamazAlarmNative_41b06378.zip"
              download="NamazAlarmNative.zip"
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-600/30 text-emerald-300 hover:bg-emerald-600/40 border border-emerald-500/40 text-xs font-semibold transition-all cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download NamazAlarmNative.zip</span>
            </a>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-zinc-800 flex items-center gap-3 shrink-0 bg-zinc-950/40">
          <button
            type="button"
            onClick={() => {
              handleStopPreview();
              onClose();
            }}
            className="flex-1 py-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 font-medium text-xs border border-zinc-800 transition-all cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="flex-1 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-semibold text-xs transition-all cursor-pointer shadow-lg shadow-amber-950/50 flex items-center justify-center gap-1"
          >
            <Check className="w-3.5 h-3.5" />
            <span>Apply Settings</span>
          </button>
        </div>
      </div>
    </div>
  );
};
