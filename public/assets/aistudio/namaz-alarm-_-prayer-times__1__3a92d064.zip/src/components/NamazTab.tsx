import React, { useEffect, useState } from 'react';
import { AlarmItem, AppSettings, CalculationMethodKey, MadhabKey } from '../types';
import { calculatePrayerTimes, formatTime12, formatTime24, formatDisplayTime, getIslamicDateString } from '../services/prayerService';
import { getTodayKey, calculatePrayerStreak } from '../services/storageService';
import { Check, Flame, Clock, Sparkles, MapPin, ChevronRight, CheckCircle2 } from 'lucide-react';
import confetti from 'canvas-confetti';
import { soundService } from '../services/soundService';

interface NamazTabProps {
  alarms: AlarmItem[];
  doneRecords: Record<string, Record<string, boolean>>;
  settings: AppSettings;
  onTogglePrayerDone: (prayerId: string) => void;
  onOpenSettings: () => void;
}

export const NamazTab: React.FC<NamazTabProps> = ({
  alarms,
  doneRecords,
  settings,
  onTogglePrayerDone,
  onOpenSettings,
}) => {
  const [now, setNow] = useState(new Date());

  // Update clock every second for countdown precision
  useEffect(() => {
    const timer = setInterval(() => {
      setNow(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const todayKey = getTodayKey();
  const todayDone = doneRecords[todayKey] || {};
  const streak = calculatePrayerStreak(doneRecords);
  const { gregorian, hijri } = getIslamicDateString(now);

  // Astronomical calculated times for current location
  const calculated = calculatePrayerTimes(
    now,
    settings.location.latitude,
    settings.location.longitude,
    settings.calculationMethod,
    settings.madhab
  );

  // Filter namaz alarms (alarms with prayer property `p`)
  const prayerAlarms = alarms.filter(a => !!a.p);
  const obligatoryAlarms = prayerAlarms.filter(a => ['Fajr', 'Zuhr', 'Asr', 'Maghrib', 'Isha'].includes(a.p || ''));
  const doneCount = obligatoryAlarms.filter(a => todayDone[a.id]).length;
  const progressPct = obligatoryAlarms.length ? Math.round((doneCount / obligatoryAlarms.length) * 100) : 0;

  // Next prayer detection (with fallback to calculated astronomical times if no alarms active)
  const nextPrayerInfo = (() => {
    const activePrayers = prayerAlarms.filter(a => a.on);
    const candidates: { name: string; urdu: string; timeStr: string; targetDate: Date }[] = [];

    if (activePrayers.length > 0) {
      for (const alarm of activePrayers) {
        const [h, m] = alarm.t.split(':').map(Number);
        const target = new Date(now);
        target.setHours(h, m, 0, 0);

        if (target <= now) {
          target.setDate(target.getDate() + 1);
        }
        candidates.push({
          name: alarm.p || 'Prayer',
          urdu: alarm.l || '',
          timeStr: alarm.t,
          targetDate: target,
        });
      }
    } else {
      // Fallback to astronomical prayer times so countdown is never blank
      const list = [
        { name: 'Tahajjud', urdu: 'تہجد کی نماز', date: calculated.tahajjud },
        { name: 'Fajr', urdu: 'نمازِ فجر', date: calculated.fajr },
        { name: 'Zuhr', urdu: 'نمازِ ظہر', date: calculated.dhuhr },
        { name: 'Asr', urdu: 'نمازِ عصر', date: calculated.asr },
        { name: 'Maghrib', urdu: 'نمازِ مغرب', date: calculated.maghrib },
        { name: 'Isha', urdu: 'نمازِ عشاء', date: calculated.isha },
      ];
      for (const item of list) {
        const target = new Date(item.date);
        if (target <= now) {
          target.setDate(target.getDate() + 1);
        }
        candidates.push({
          name: item.name,
          urdu: item.urdu,
          timeStr: formatTime24(item.date),
          targetDate: target,
        });
      }
    }

    let best: { name: string; urdu: string; timeStr: string; diffMs: number } | null = null;
    for (const c of candidates) {
      const diff = c.targetDate.getTime() - now.getTime();
      if (!best || diff < best.diffMs) {
        best = { ...c, diffMs: diff };
      }
    }

    if (!best) return null;

    const totalSeconds = Math.floor(best.diffMs / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    return {
      name: best.name,
      urdu: best.urdu,
      timeStr: best.timeStr,
      hours,
      minutes,
      seconds,
    };
  })();

  const handleCheck = (id: string) => {
    const wasDone = !!todayDone[id];
    onTogglePrayerDone(id);

    if (!wasDone) {
      soundService.playTasbihClick();
      // If completing all 5 prayers, celebrate with confetti & sound!
      if (doneCount + 1 === obligatoryAlarms.length) {
        soundService.playTasbihComplete();
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#34c759', '#ff9f0a', '#ffffff'],
        });
      }
    }
  };

  const timetableItems = [
    { label: 'Tahajjud (Last 3rd)', time: formatDisplayTime(calculated.tahajjud, settings.timeFormat24), urdu: 'تہجد' },
    { label: 'Fajr (Dawn)', time: formatDisplayTime(calculated.fajr, settings.timeFormat24), urdu: 'فجر' },
    { label: 'Sunrise', time: formatDisplayTime(calculated.sunrise, settings.timeFormat24), urdu: 'طلوعِ آفتاب' },
    { label: 'Zuhr (Noon)', time: formatDisplayTime(calculated.dhuhr, settings.timeFormat24), urdu: 'ظہر' },
    { label: 'Asr (Afternoon)', time: formatDisplayTime(calculated.asr, settings.timeFormat24), urdu: 'عصر' },
    { label: 'Maghrib (Sunset)', time: formatDisplayTime(calculated.maghrib, settings.timeFormat24), urdu: 'مغرب' },
    { label: 'Isha (Night)', time: formatDisplayTime(calculated.isha, settings.timeFormat24), urdu: 'عشاء' },
  ];

  return (
    <div className="pb-24 max-w-lg mx-auto space-y-4 px-4 pt-3">
      {/* Title */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-white">Namaz Tracker</h2>
          <p className="text-xs text-zinc-400 mt-0.5">Daily obligatory & voluntary prayers</p>
        </div>
        {streak > 0 && (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold">
            <Flame className="w-4 h-4 fill-amber-400" />
            <span>{streak} Day Streak</span>
          </div>
        )}
      </div>

      {/* Card 1: Next Prayer Hero */}
      <div className="rounded-3xl bg-gradient-to-br from-[#1c1c1e] to-[#252528] border border-zinc-800 p-5 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />
        
        <div className="flex items-center justify-between text-xs text-zinc-400 font-medium">
          <span className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-emerald-400" />
            <span>Next Prayer</span>
          </span>
          <span className="text-emerald-400 font-medium">
            {nextPrayerInfo ? formatDisplayTime(nextPrayerInfo.timeStr, settings.timeFormat24) : ''}
          </span>
        </div>

        {nextPrayerInfo ? (
          <div className="mt-3">
            <div className="flex items-baseline justify-between">
              <div className="text-4xl font-bold text-white tracking-tight">
                {nextPrayerInfo.name}
              </div>
              <div className="text-sm font-urdu text-zinc-300">
                {nextPrayerInfo.urdu}
              </div>
            </div>

            <div className="mt-2 text-2xl font-mono text-amber-400 flex items-baseline gap-1">
              <span className="text-sm font-sans text-zinc-400 mr-1">starts in</span>
              <span>{nextPrayerInfo.hours}h</span>
              <span className="text-zinc-500">:</span>
              <span>{String(nextPrayerInfo.minutes).padStart(2, '0')}m</span>
              <span className="text-zinc-500">:</span>
              <span className="text-lg text-amber-400/80">
                {String(nextPrayerInfo.seconds).padStart(2, '0')}s
              </span>
            </div>
          </div>
        ) : (
          <div className="mt-3 text-zinc-400 text-sm">
            Calculating upcoming prayer timings...
          </div>
        )}

        {/* Date Row */}
        <div className="mt-4 pt-3 border-t border-zinc-800/80 flex flex-wrap items-center justify-between text-xs text-zinc-400 gap-2">
          <span>{gregorian}</span>
          <span className="text-amber-400/90 font-medium">{hijri}</span>
        </div>
      </div>

      {/* Card 2: Today's Prayers Progress */}
      <div className="rounded-2xl bg-[#1c1c1e] border border-zinc-800 p-4 space-y-2.5">
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-2">
            <span className="font-medium text-white">Today's Prayers</span>
            {doneCount === obligatoryAlarms.length && obligatoryAlarms.length > 0 && (
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1 font-semibold">
                <Sparkles className="w-3 h-3" />
                Completed
              </span>
            )}
          </div>
          <span className="font-mono text-zinc-300 text-xs">
            <b className="text-emerald-400 text-sm font-semibold">{doneCount}</b> of {obligatoryAlarms.length}
          </span>
        </div>

        {/* Progress Bar */}
        <div className="h-2.5 bg-zinc-800 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-emerald-500 to-emerald-400 transition-all duration-500 ease-out"
            style={{ width: `${progressPct}%` }}
          />
        </div>
      </div>

      {/* Prayers Checklist */}
      <div className="rounded-3xl bg-[#1c1c1e] border border-zinc-800 divide-y divide-zinc-800/80 overflow-hidden shadow-lg">
        {prayerAlarms.map(a => {
          const isDone = !!todayDone[a.id];
          const timeFormatted = formatTime12(a.t);

          return (
            <div
              key={a.id}
              onClick={() => handleCheck(a.id)}
              className={`p-4 flex items-center gap-3.5 transition-all cursor-pointer select-none hover:bg-zinc-800/40 ${
                isDone ? 'bg-emerald-950/15' : ''
              }`}
            >
              {/* Custom Circular Checkbox */}
              <button
                type="button"
                onClick={e => {
                  e.stopPropagation();
                  handleCheck(a.id);
                }}
                className={`w-7 h-7 rounded-full flex items-center justify-center transition-all cursor-pointer shrink-0 ${
                  isDone
                    ? 'bg-emerald-500 text-black shadow-md shadow-emerald-950/40'
                    : 'border-2 border-zinc-600 hover:border-zinc-400 bg-transparent'
                }`}
                aria-label={`Mark ${a.p} as prayed`}
              >
                {isDone && <Check className="w-4 h-4 stroke-[3]" />}
              </button>

              {/* Title & Time */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span
                    className={`font-semibold text-base transition-colors ${
                      isDone ? 'line-through text-zinc-500' : 'text-white'
                    }`}
                  >
                    {a.p}
                  </span>
                </div>
                <div className="text-xs text-zinc-400 font-mono mt-0.5">
                  {formatDisplayTime(a.t, settings.timeFormat24)}
                </div>
              </div>

              {/* Urdu Name */}
              <div className="text-right shrink-0">
                <div className={`font-urdu text-sm ${isDone ? 'text-zinc-500' : 'text-zinc-200'}`}>
                  {a.l}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Astronomical Calculated Timetable Accordion Card */}
      <div className="rounded-3xl bg-[#1c1c1e] border border-zinc-800 p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
              <span>Astronomical Timetable</span>
              <span className="text-[10px] font-normal px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-400">
                {settings.madhab.toUpperCase()}
              </span>
            </h3>
            <p className="text-[11px] text-zinc-400 flex items-center gap-1 mt-0.5">
              <MapPin className="w-3 h-3 text-emerald-400" />
              <span>{settings.location.city} ({settings.calculationMethod})</span>
            </p>
          </div>
          <button
            onClick={onOpenSettings}
            className="text-xs text-amber-400 hover:text-amber-300 font-medium flex items-center gap-0.5 cursor-pointer"
          >
            <span>Change</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-2 pt-1 text-xs">
          {timetableItems.map(item => (
            <div
              key={item.label}
              className="p-2.5 rounded-xl bg-zinc-900/80 border border-zinc-800 flex items-center justify-between"
            >
              <div>
                <div className="text-zinc-400 text-[11px]">{item.label}</div>
                <div className="font-mono font-semibold text-white mt-0.5">{item.time}</div>
              </div>
              <div className="font-urdu text-zinc-400 text-xs">{item.urdu}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
