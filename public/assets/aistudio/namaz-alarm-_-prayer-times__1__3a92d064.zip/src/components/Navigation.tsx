import React from 'react';
import { TabType } from '../types';
import { Bell, Clock, Compass, CheckSquare, Sparkles } from 'lucide-react';

interface NavigationProps {
  currentTab: TabType;
  onSelectTab: (tab: TabType) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ currentTab, onSelectTab }) => {
  const tabs: { id: TabType; label: string; icon: React.ReactNode }[] = [
    { id: 'alarms', label: 'Alarms', icon: <Bell className="w-5 h-5" /> },
    { id: 'namaz', label: 'Namaz', icon: <Clock className="w-5 h-5" /> },
    { id: 'qibla', label: 'Qibla', icon: <Compass className="w-5 h-5" /> },
    { id: 'tasks', label: 'Tasks', icon: <CheckSquare className="w-5 h-5" /> },
    { id: 'tasbih', label: 'Tasbih', icon: <Sparkles className="w-5 h-5" /> },
  ];

  return (
    <nav className="fixed bottom-3 left-1/2 -translate-x-1/2 w-[calc(100%-24px)] max-w-[440px] bg-[#1c1c1e]/90 backdrop-blur-xl border border-white/10 rounded-full p-1.5 z-40 shadow-2xl flex items-center justify-between">
      {tabs.map(tab => {
        const isActive = currentTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onSelectTab(tab.id)}
            className={`flex-1 flex flex-col items-center justify-center py-2 px-1 rounded-full transition-all duration-200 cursor-pointer ${
              isActive
                ? 'bg-[#2c2c2e] text-amber-400 shadow-md'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <div className={`transition-transform duration-200 ${isActive ? 'scale-110' : 'scale-100 opacity-75'}`}>
              {tab.icon}
            </div>
            <span className="text-[10px] font-medium tracking-wide mt-0.5">{tab.label}</span>
          </button>
        );
      })}
    </nav>
  );
};
