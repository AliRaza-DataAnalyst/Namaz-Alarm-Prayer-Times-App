import React, { useState } from 'react';
import { AlarmItem, AppSettings } from '../types';
import { formatTime12 } from '../services/prayerService';
import { Plus, RefreshCw, Volume2, Trash2, Check, Sparkles } from 'lucide-react';
import { soundService } from '../services/soundService';

interface AlarmsTabProps {
  alarms: AlarmItem[];
  settings: AppSettings;
  onUpdateAlarms: (alarms: AlarmItem[]) => void;
  onSyncWithCalculated: () => void;
  onTestAlarm: (alarm: AlarmItem) => void;
}

const DAYS_SHORT = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
const DAYS_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

const PRAYER_PRESETS: { name: string; urdu: string; defaultTime: string }[] = [
  { name: 'Tahajjud', urdu: '🫀 تہجد کی نماز + صلوۃ الحاجات کی نماز', defaultTime: '04:00' },
  { name: 'Fajr', urdu: '💗 نمازِ فجر', defaultTime: '04:35' },
  { name: 'Ishraq', urdu: '☀️ نمازِ اشراق و چاشت', defaultTime: '06:45' },
  { name: 'Zuhr', urdu: '🫶 نمازِ ظہر', defaultTime: '13:30' },
  { name: 'Asr', urdu: '❤️ نمازِ عصر', defaultTime: '16:20' },
  { name: 'Maghrib', urdu: '🫶🤍 نمازِ مغرب', defaultTime: '18:00' },
  { name: 'Isha', urdu: '🫶 🫀 نمازِ عشاء', defaultTime: '19:15' },
];

export const AlarmsTab: React.FC<AlarmsTabProps> = ({
  alarms,
  settings,
  onUpdateAlarms,
  onSyncWithCalculated,
  onTestAlarm,
}) => {
  const [editingAlarm, setEditingAlarm] = useState<AlarmItem | null>(null);
  const [isNew, setIsNew] = useState(false);

  // Repeat text helper
  const formatRepeat = (days: number[] = []) => {
    if (days.length === 7) return 'every day';
    if (!days.length) return 'once';
    return days.map(d => DAYS_NAMES[d]).join(' ');
  };

  const handleToggle = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    soundService.requestNotificationPermission();
    const updated = alarms.map(a => (a.id === id ? { ...a, on: !a.on } : a));
    onUpdateAlarms(updated);
  };

  const openNewAlarm = () => {
    setIsNew(true);
    setEditingAlarm({
      id: 'a_' + Date.now(),
      t: '06:00',
      l: 'یاد دہانی',
      on: true,
      d: [0, 1, 2, 3, 4, 5, 6],
    });
  };

  const openEditAlarm = (alarm: AlarmItem) => {
    setIsNew(false);
    setEditingAlarm({ ...alarm });
  };

  const handleSave = () => {
    if (!editingAlarm) return;
    let updated: AlarmItem[];
    if (isNew) {
      updated = [...alarms, editingAlarm];
    } else {
      updated = alarms.map(a => (a.id === editingAlarm.id ? editingAlarm : a));
    }
    onUpdateAlarms(updated);
    setEditingAlarm(null);
  };

  const handleDelete = () => {
    if (!editingAlarm) return;
    const updated = alarms.filter(a => a.id !== editingAlarm.id);
    onUpdateAlarms(updated);
    setEditingAlarm(null);
  };

  const toggleDay = (dayIndex: number) => {
    if (!editingAlarm) return;
    const currentDays = editingAlarm.d || [];
    const exists = currentDays.includes(dayIndex);
    const newDays = exists
      ? currentDays.filter(d => d !== dayIndex)
      : [...currentDays, dayIndex].sort();
    setEditingAlarm({ ...editingAlarm, d: newDays });
  };

  const sortedAlarms = [...alarms].sort((a, b) => a.t.localeCompare(b.t));

  return (
    <div className="pb-24 max-w-lg mx-auto">
      {/* Top Title & Actions */}
      <div className="px-4 py-4 flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-white">Prayer Alarms</h2>
          <p className="text-xs text-zinc-400 mt-0.5">
            {alarms.filter(a => a.on).length} active of {alarms.length} alarms
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onSyncWithCalculated}
            title="Auto-Sync Times with Location"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 hover:text-emerald-400 hover:border-emerald-500/40 transition-all cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Sync Times</span>
          </button>
          <button
            onClick={openNewAlarm}
            className="w-9 h-9 rounded-full bg-amber-500 hover:bg-amber-400 text-black flex items-center justify-center font-bold text-xl shadow-lg shadow-amber-950/40 cursor-pointer active:scale-95 transition-all"
            aria-label="Add alarm"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Alarms List */}
      <div className="divide-y divide-zinc-800/80 border-t border-b border-zinc-800/80">
        {sortedAlarms.length === 0 ? (
          <div className="text-center py-12 px-4 text-zinc-500">
            <p>No alarms configured.</p>
            <button
              onClick={openNewAlarm}
              className="mt-3 px-4 py-2 rounded-xl bg-amber-500/20 text-amber-400 text-xs font-semibold"
            >
              Add First Alarm
            </button>
          </div>
        ) : (
          sortedAlarms.map(a => {
            const formatted = formatTime12(a.t);
            return (
              <div
                key={a.id}
                onClick={() => openEditAlarm(a)}
                className={`px-4 py-3.5 flex items-center justify-between transition-colors hover:bg-zinc-900/50 cursor-pointer ${
                  a.on ? 'opacity-100' : 'opacity-40'
                }`}
              >
                <div className="min-w-0 pr-4">
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-4xl sm:text-5xl font-light tracking-tight font-mono text-white">
                      {settings.timeFormat24 ? a.t : formatted.time}
                    </span>
                    {!settings.timeFormat24 && (
                      <span className="text-xl sm:text-2xl font-light text-zinc-400">
                        {formatted.ap}
                      </span>
                    )}
                    {a.p && (
                      <span className="ml-2 text-xs font-medium px-2 py-0.5 rounded-full bg-zinc-800 text-emerald-400 border border-zinc-700/50">
                        {a.p}
                      </span>
                    )}
                  </div>
                  <div className="mt-1 flex items-center gap-1.5 text-xs text-zinc-400 truncate">
                    <span>{formatRepeat(a.d)}</span>
                    <span>•</span>
                    <span className="font-urdu text-sm text-zinc-200 truncate">{a.l}</span>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <button
                    onClick={e => {
                      e.stopPropagation();
                      onTestAlarm(a);
                    }}
                    title="Test Sound"
                    className="p-2 text-zinc-400 hover:text-amber-400 transition-colors"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>

                  {/* Switch */}
                  <button
                    onClick={e => handleToggle(a.id, e)}
                    className={`w-[51px] h-[31px] rounded-full p-[2px] transition-colors duration-200 cursor-pointer relative ${
                      a.on ? 'bg-[#34c759]' : 'bg-[#39393d]'
                    }`}
                    aria-label="Toggle alarm"
                  >
                    <div
                      className={`w-[27px] h-[27px] rounded-full bg-white shadow-md transition-transform duration-200 ${
                        a.on ? 'translate-x-[20px]' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Edit / New Alarm Bottom Sheet Modal */}
      {editingAlarm && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in"
          onClick={() => setEditingAlarm(null)}
        >
          <div
            className="w-full max-w-lg bg-[#1c1c1e] border-t sm:border border-zinc-800 rounded-t-3xl sm:rounded-3xl p-6 shadow-2xl space-y-5"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
              <h3 className="text-lg font-bold text-white">
                {isNew ? 'New Alarm' : 'Edit Alarm'}
              </h3>
              <button
                onClick={() => setEditingAlarm(null)}
                className="text-xs text-zinc-400 hover:text-white"
              >
                Close
              </button>
            </div>

            {/* Time Picker */}
            <div className="flex flex-col items-center justify-center py-2">
              <label className="text-xs text-zinc-500 mb-1 uppercase tracking-wider font-semibold">
                Alarm Time
              </label>
              <input
                type="time"
                value={editingAlarm.t}
                onChange={e => setEditingAlarm({ ...editingAlarm, t: e.target.value })}
                className="bg-black/60 border border-zinc-700 rounded-2xl px-6 py-3 text-4xl sm:text-5xl font-mono text-center text-white focus:outline-none focus:border-amber-500 transition-colors w-full max-w-[280px]"
              />
            </div>

            {/* Quick Prayer Preset selector */}
            <div>
              <label className="text-xs text-zinc-400 mb-2 block font-medium flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Quick Prayer Presets</span>
              </label>
              <div className="flex flex-wrap gap-1.5">
                {PRAYER_PRESETS.map(p => (
                  <button
                    key={p.name}
                    type="button"
                    onClick={() => {
                      setEditingAlarm({
                        ...editingAlarm,
                        p: p.name,
                        l: p.urdu,
                        t: isNew ? p.defaultTime : editingAlarm.t,
                      });
                    }}
                    className={`px-2.5 py-1 text-xs rounded-lg border transition-all cursor-pointer ${
                      editingAlarm.p === p.name
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50'
                        : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                    }`}
                  >
                    {p.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Label input */}
            <div>
              <label className="text-xs text-zinc-400 mb-1.5 block font-medium">
                Label & Urdu Name
              </label>
              <input
                type="text"
                placeholder="Label (e.g. 💗 نمازِ فجر)"
                value={editingAlarm.l}
                onChange={e => setEditingAlarm({ ...editingAlarm, l: e.target.value })}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500 font-urdu"
              />
            </div>

            {/* Days of week selector chips */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs text-zinc-400 font-medium">Repeat</label>
                <div className="flex gap-2 text-[11px]">
                  <button
                    type="button"
                    onClick={() => setEditingAlarm({ ...editingAlarm, d: [0, 1, 2, 3, 4, 5, 6] })}
                    className="text-amber-400 hover:underline cursor-pointer"
                  >
                    Everyday
                  </button>
                  <span className="text-zinc-600">|</span>
                  <button
                    type="button"
                    onClick={() => setEditingAlarm({ ...editingAlarm, d: [] })}
                    className="text-zinc-400 hover:underline cursor-pointer"
                  >
                    Once
                  </button>
                </div>
              </div>
              <div className="grid grid-cols-7 gap-1.5">
                {DAYS_SHORT.map((d, index) => {
                  const isSelected = editingAlarm.d?.includes(index);
                  return (
                    <button
                      key={index}
                      type="button"
                      onClick={() => toggleDay(index)}
                      className={`h-10 rounded-xl font-semibold text-xs transition-all cursor-pointer flex items-center justify-center ${
                        isSelected
                          ? 'bg-amber-500 text-black shadow-md shadow-amber-950/40'
                          : 'bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800'
                      }`}
                    >
                      {d}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Action buttons */}
            <div className="pt-2 flex items-center gap-3">
              {!isNew && (
                <button
                  type="button"
                  onClick={handleDelete}
                  className="p-3 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 transition-all cursor-pointer flex items-center justify-center"
                  title="Delete Alarm"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              )}
              <button
                type="button"
                onClick={() => setEditingAlarm(null)}
                className="flex-1 py-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 font-medium text-sm border border-zinc-800 transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSave}
                className="flex-1 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-semibold text-sm transition-all cursor-pointer shadow-lg shadow-amber-950/50 flex items-center justify-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>Save Alarm</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
