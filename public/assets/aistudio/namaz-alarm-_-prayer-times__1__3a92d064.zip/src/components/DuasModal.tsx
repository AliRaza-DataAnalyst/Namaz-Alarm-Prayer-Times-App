import React, { useState } from 'react';
import { MASNOON_DUAS } from '../data/dhikrAndDuas';
import { X, Search, Copy, Check, BookOpen } from 'lucide-react';
import { soundService } from '../services/soundService';

interface DuasModalProps {
  onClose: () => void;
}

export const DuasModal: React.FC<DuasModalProps> = ({ onClose }) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const categories = [
    { id: 'all', label: 'All Duas' },
    { id: 'after_namaz', label: 'After Namaz' },
    { id: 'morning_evening', label: 'Morning & Wake' },
    { id: 'sleep', label: 'Sleep & Night' },
    { id: 'forgiveness', label: 'Forgiveness' },
  ];

  const filteredDuas = MASNOON_DUAS.filter(d => {
    const matchesCat = activeCategory === 'all' || d.category === activeCategory;
    const matchesSearch =
      searchQuery === '' ||
      d.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.arabic.includes(searchQuery) ||
      d.urduTitle.includes(searchQuery) ||
      d.urduTranslation.includes(searchQuery) ||
      d.translation.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    soundService.playTasbihClick();
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="w-full max-w-xl max-h-[90vh] bg-[#1c1c1e] border-t sm:border border-zinc-800 rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-zinc-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Masnoon Duas</h3>
              <p className="text-[11px] text-zinc-400">Authentic supplications from Sunnah</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Categories */}
        <div className="p-4 space-y-3 border-b border-zinc-800 shrink-0 bg-zinc-950/40">
          {/* Search bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by topic, Arabic, or Urdu..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-[#2c2c2e] border border-zinc-700/60 rounded-xl text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500 transition-colors"
            />
          </div>

          {/* Categories */}
          <div className="flex gap-1.5 overflow-x-auto scrollbar-none pb-1">
            {categories.map(c => (
              <button
                key={c.id}
                onClick={() => setActiveCategory(c.id)}
                className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
                  activeCategory === c.id
                    ? 'bg-amber-500 text-black shadow-sm'
                    : 'bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white'
                }`}
              >
                {c.label}
              </button>
            ))}
          </div>
        </div>

        {/* Dua Cards List */}
        <div className="p-4 overflow-y-auto space-y-4 flex-1">
          {filteredDuas.length === 0 ? (
            <div className="text-center py-12 text-zinc-500 text-xs">
              No supplications match your search.
            </div>
          ) : (
            filteredDuas.map(d => (
              <div
                key={d.id}
                className="rounded-2xl bg-zinc-900/90 border border-zinc-800 p-4 space-y-3 shadow-md"
              >
                {/* Title and copy */}
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h4 className="font-semibold text-white text-sm">{d.title}</h4>
                    <div className="font-urdu text-amber-400 text-xs mt-0.5">{d.urduTitle}</div>
                  </div>
                  <button
                    onClick={() => handleCopy(d.id, `${d.arabic}\n\n${d.urduTranslation}\n\n${d.translation}`)}
                    className="p-1.5 rounded-lg bg-zinc-800 text-zinc-400 hover:text-white transition-colors cursor-pointer shrink-0"
                    title="Copy Dua"
                  >
                    {copiedId === d.id ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>

                {/* Arabic Text */}
                <div dir="rtl" className="p-3.5 rounded-xl bg-black/60 border border-zinc-800/80 text-right">
                  <p className="font-arabic text-xl sm:text-2xl text-emerald-300 leading-relaxed font-bold">
                    {d.arabic}
                  </p>
                </div>

                {/* Transliteration */}
                <div className="text-xs text-zinc-400 italic">
                  "{d.transliteration}"
                </div>

                {/* Urdu Translation */}
                <div dir="rtl" className="p-2.5 rounded-lg bg-zinc-950/40 border border-zinc-800 text-right font-urdu text-xs sm:text-sm text-zinc-200 leading-loose">
                  {d.urduTranslation}
                </div>

                {/* English Translation */}
                <div className="text-xs text-zinc-300">
                  <span className="text-zinc-500 font-semibold mr-1">Meaning:</span>
                  {d.translation}
                </div>

                {/* Reference */}
                <div className="text-[10px] text-zinc-500 font-mono">
                  {d.reference}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
