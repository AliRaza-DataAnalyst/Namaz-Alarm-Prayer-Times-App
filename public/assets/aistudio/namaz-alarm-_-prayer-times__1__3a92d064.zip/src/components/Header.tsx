import React from 'react';
import { Volume2, BookOpen, Settings, MapPin } from 'lucide-react';
import { AppSettings } from '../types';

interface HeaderProps {
  settings: AppSettings;
  onOpenSettings: () => void;
  onOpenDuas: () => void;
  onTriggerTestAlarm: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  onOpenSettings,
  onOpenDuas,
  onTriggerTestAlarm,
}) => {
  return (
    <header className="px-4 pt-4 pb-2 flex items-center justify-between border-b border-zinc-800/60 sticky top-0 bg-black/80 backdrop-blur-md z-30">
      <div className="flex items-center gap-2.5">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-amber-500 flex items-center justify-center shadow-lg shadow-emerald-950/40 border border-white/10">
          <span className="text-lg">🕌</span>
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-lg font-bold tracking-tight text-white leading-none">Namaz Alarm</h1>
            <span className="text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              Pro
            </span>
          </div>
          <button
            onClick={onOpenSettings}
            className="flex items-center gap-1 text-[11px] text-zinc-400 hover:text-amber-400 transition-colors mt-0.5 text-left"
          >
            <MapPin className="w-3 h-3 text-emerald-400" />
            <span>{settings.location.city}, {settings.location.country}</span>
          </button>
        </div>
      </div>

      <div className="flex items-center gap-1.5">
        <button
          onClick={onTriggerTestAlarm}
          title="Test Ring Alarm"
          className="p-2 rounded-xl bg-zinc-900/90 text-amber-400 hover:bg-zinc-800 border border-zinc-800 transition-all cursor-pointer flex items-center gap-1 text-xs font-medium"
        >
          <Volume2 className="w-4 h-4" />
          <span className="hidden sm:inline">Test Ring</span>
        </button>

        <button
          onClick={onOpenDuas}
          title="Masnoon Duas"
          className="p-2 rounded-xl bg-zinc-900/90 text-zinc-300 hover:text-white hover:bg-zinc-800 border border-zinc-800 transition-all cursor-pointer"
        >
          <BookOpen className="w-4 h-4" />
        </button>

        <button
          onClick={onOpenSettings}
          title="Settings & Calculation"
          className="p-2 rounded-xl bg-zinc-900/90 text-zinc-300 hover:text-white hover:bg-zinc-800 border border-zinc-800 transition-all cursor-pointer"
        >
          <Settings className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
