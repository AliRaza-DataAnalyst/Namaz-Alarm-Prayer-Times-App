import React, { useEffect } from 'react';
import { Bell, Volume2, Moon, Sparkles } from 'lucide-react';
import { formatTime12 } from '../services/prayerService';
import { soundService } from '../services/soundService';
import { AppSettings } from '../types';

interface RingingAlarmModalProps {
  label: string;
  time: string;
  prayerName?: string;
  settings: AppSettings;
  onDismiss: () => void;
  onSnooze: (minutes: number) => void;
}

export const RingingAlarmModal: React.FC<RingingAlarmModalProps> = ({
  label,
  time,
  prayerName,
  settings,
  onDismiss,
  onSnooze,
}) => {
  useEffect(() => {
    // Start audio loop & vibration
    soundService.startAlarmLoop(settings.sound, settings.volume);

    // Dispatch Web Notification if enabled
    soundService.dispatchNotification(
      `🕌 ${prayerName || 'Namaz Alarm'}: ${time}`,
      label || 'It is time for prayer. Hayya alas-Salah!'
    );

    return () => {
      soundService.stopAlarm();
    };
  }, [settings.sound, settings.volume, label, time, prayerName]);

  const timeFormatted = formatTime12(time || new Date());

  return (
    <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-2xl flex flex-col items-center justify-between p-6 sm:p-10 select-none animate-in fade-in duration-300">
      {/* Ambient background glow */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[340px] h-[340px] bg-gradient-to-tr from-emerald-600/30 to-amber-500/20 rounded-full blur-3xl animate-pulse" />
      </div>

      {/* Top indicator */}
      <div className="relative z-10 flex flex-col items-center mt-6">
        <div className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-zinc-900/90 border border-amber-500/30 text-amber-400 text-xs font-semibold tracking-wider uppercase mb-3">
          <Bell className="w-3.5 h-3.5 animate-bounce" />
          <span>Prayer Alarm Active</span>
        </div>
        <p className="text-zinc-400 text-sm">حَيَّ عَلَى الصَّلَاةِ · Come to prayer</p>
      </div>

      {/* Main Clock & Label */}
      <div className="relative z-10 flex flex-col items-center text-center max-w-md my-auto">
        <div className="w-24 h-24 rounded-full bg-emerald-500/10 border-2 border-emerald-500/40 flex items-center justify-center mb-6 shadow-xl shadow-emerald-950/50 animate-soft-pulse">
          <Moon className="w-12 h-12 text-emerald-400" />
        </div>

        <div className="text-7xl sm:text-8xl font-light tracking-tight text-white mb-2 font-mono">
          {settings.timeFormat24 ? time : timeFormatted.time}
          {!settings.timeFormat24 && (
            <span className="text-3xl sm:text-4xl ml-2 font-sans font-normal text-amber-400">
              {timeFormatted.ap}
            </span>
          )}
        </div>

        {prayerName && (
          <div className="text-2xl font-bold text-emerald-400 tracking-wide mb-2 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <span>{prayerName} Prayer</span>
          </div>
        )}

        <div dir="rtl" className="text-xl sm:text-2xl text-zinc-200 font-urdu text-center max-w-sm px-4 leading-relaxed mt-2 text-balance">
          {label || 'نماز کا وقت ہو گیا ہے'}
        </div>

        <div className="mt-4 flex items-center gap-1.5 text-xs text-zinc-500">
          <Volume2 className="w-3.5 h-3.5 animate-pulse text-amber-400" />
          <span>Playing {settings.sound.replace('_', ' ')}</span>
        </div>
      </div>

      {/* Actions */}
      <div className="relative z-10 w-full max-w-xs flex flex-col gap-3 mb-6">
        <button
          onClick={onDismiss}
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-bold text-lg tracking-wide shadow-xl shadow-amber-950/50 active:scale-98 transition-all cursor-pointer"
        >
          Stop Alarm
        </button>

        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => onSnooze(5)}
            className="py-3 px-4 rounded-xl bg-zinc-900/90 hover:bg-zinc-800 text-zinc-300 hover:text-white font-medium text-sm border border-zinc-800 transition-all cursor-pointer text-center"
          >
            Snooze 5 min
          </button>
          <button
            onClick={() => onSnooze(10)}
            className="py-3 px-4 rounded-xl bg-zinc-900/90 hover:bg-zinc-800 text-zinc-300 hover:text-white font-medium text-sm border border-zinc-800 transition-all cursor-pointer text-center"
          >
            Snooze 10 min
          </button>
        </div>
      </div>
    </div>
  );
};
