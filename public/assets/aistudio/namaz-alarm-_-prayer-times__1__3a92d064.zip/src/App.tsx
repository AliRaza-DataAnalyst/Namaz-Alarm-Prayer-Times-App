import React, { useState, useEffect, useRef } from 'react';
import { TabType, AlarmItem, TaskItem, TasbihState, AppSettings } from './types';
import {
  loadStoredData,
  saveStoredData,
  getTodayKey,
} from './services/storageService';
import { calculatePrayerTimes, formatTime24 } from './services/prayerService';
import { soundService } from './services/soundService';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { AlarmsTab } from './components/AlarmsTab';
import { NamazTab } from './components/NamazTab';
import { QiblaTab } from './components/QiblaTab';
import { TasksTab } from './components/TasksTab';
import { TasbihTab } from './components/TasbihTab';
import { RingingAlarmModal } from './components/RingingAlarmModal';
import { SettingsModal } from './components/SettingsModal';
import { DuasModal } from './components/DuasModal';
import confetti from 'canvas-confetti';

export default function App() {
  const [tab, setTab] = useState<TabType>('alarms');
  const [data, setData] = useState(() => loadStoredData());
  const [ringingAlarm, setRingingAlarm] = useState<{
    label: string;
    time: string;
    prayerName?: string;
  } | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [showDuas, setShowDuas] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Keep track of which alarms fired in the current minute to avoid double-ringing
  const lastFiredMinuteRef = useRef<string>('');

  // Sync state to local storage and native Android bridge
  useEffect(() => {
    saveStoredData(data);

    // If running inside Android WebView with native bridge
    try {
      const win = window as unknown as {
        NamazAlarmNative?: {
          syncAlarms: (alarms: string, tasks: string) => void;
        };
      };
      if (win.NamazAlarmNative && typeof win.NamazAlarmNative.syncAlarms === 'function') {
        win.NamazAlarmNative.syncAlarms(
          JSON.stringify(data.alarms),
          JSON.stringify(data.tasks)
        );
      }
    } catch (e) {
      console.warn('Native bridge sync error', e);
    }
  }, [data]);

  // Unlock Web Audio API on first user gesture
  useEffect(() => {
    const handleFirstInteraction = () => {
      soundService.unlockAudio();
    };
    window.addEventListener('click', handleFirstInteraction, { once: true, passive: true });
    window.addEventListener('touchstart', handleFirstInteraction, { once: true, passive: true });
    return () => {
      window.removeEventListener('click', handleFirstInteraction);
      window.removeEventListener('touchstart', handleFirstInteraction);
    };
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(prev => (prev === msg ? null : prev));
    }, 3500);
  };

  // Alarm clock ticker: checks every 5 seconds
  useEffect(() => {
    const checkAlarms = () => {
      const now = new Date();
      const currentH = String(now.getHours()).padStart(2, '0');
      const currentM = String(now.getMinutes()).padStart(2, '0');
      const currentTimeStr = `${currentH}:${currentM}`;
      const currentDayOfWeek = now.getDay(); // 0=Sun, 1=Mon, ..., 6=Sat

      const currentMinuteKey = `${now.toDateString()}_${currentTimeStr}`;
      if (lastFiredMinuteRef.current === currentMinuteKey) {
        return; // already checked this minute
      }

      // Check alarms
      for (const alarm of data.alarms) {
        if (!alarm.on) continue;
        if (alarm.t !== currentTimeStr) continue;

        // Check day repeat
        const matchesDay =
          alarm.d.length === 0 || // one-shot
          alarm.d.length === 7 || // every day
          alarm.d.includes(currentDayOfWeek);

        if (matchesDay) {
          lastFiredMinuteRef.current = currentMinuteKey;
          setRingingAlarm({
            label: alarm.l || 'Namaz Reminder',
            time: currentTimeStr,
            prayerName: alarm.p,
          });

          // If one-shot alarm, turn it off so it doesn't repeat tomorrow
          if (alarm.d.length === 0) {
            setData(prev => ({
              ...prev,
              alarms: prev.alarms.map(a => (a.id === alarm.id ? { ...a, on: false } : a)),
            }));
          }
          return;
        }
      }

      // Check tasks reminders
      for (const task of data.tasks) {
        if (task.x) continue;
        if (task.t && task.t === currentTimeStr && task.fired !== currentMinuteKey) {
          lastFiredMinuteRef.current = currentMinuteKey;
          setData(prev => ({
            ...prev,
            tasks: prev.tasks.map(t => (t.id === task.id ? { ...t, fired: currentMinuteKey } : t)),
          }));
          setRingingAlarm({
            label: `Task: ${task.n}`,
            time: currentTimeStr,
          });
          return;
        }
      }
    };

    const interval = setInterval(checkAlarms, 5000);
    return () => clearInterval(interval);
  }, [data.alarms, data.tasks]);

  // Sync standard prayer alarms with calculated astronomical times
  const handleSyncWithCalculated = () => {
    const calculated = calculatePrayerTimes(
      new Date(),
      data.settings.location.latitude,
      data.settings.location.longitude,
      data.settings.calculationMethod,
      data.settings.madhab
    );

    // Ishraq is 15 minutes after sunrise
    const ishraqTime = new Date(calculated.sunrise.getTime() + 15 * 60 * 1000);

    const timeMap: Record<string, string> = {
      Tahajjud: formatTime24(calculated.tahajjud),
      Fajr: formatTime24(calculated.fajr),
      Ishraq: formatTime24(ishraqTime),
      Zuhr: formatTime24(calculated.dhuhr),
      Asr: formatTime24(calculated.asr),
      Maghrib: formatTime24(calculated.maghrib),
      Isha: formatTime24(calculated.isha),
    };

    const updated = data.alarms.map(a => {
      if (a.p && timeMap[a.p]) {
        return { ...a, t: timeMap[a.p] };
      }
      return a;
    });

    setData(prev => ({ ...prev, alarms: updated }));
    soundService.playTasbihClick();
    showToast(`Synced prayer alarms to ${data.settings.location.city} timings!`);
  };

  // Test ring action
  const handleTriggerTest = (customAlarm?: AlarmItem) => {
    const label = customAlarm ? customAlarm.l : 'Test Namaz Reminder (نماز کی یاد دہانی)';
    const time = customAlarm ? customAlarm.t : formatTime24(new Date());
    const prayerName = customAlarm ? customAlarm.p : 'Fajr';

    setRingingAlarm({
      label,
      time,
      prayerName,
    });
  };

  const handleSnooze = (minutes: number) => {
    const currentLabel = ringingAlarm?.label || 'Snoozed Namaz Alarm';
    const currentPrayerName = ringingAlarm?.prayerName;
    setRingingAlarm(null);
    showToast(`Alarm snoozed for ${minutes} minutes.`);

    setTimeout(() => {
      setRingingAlarm({
        label: currentLabel,
        time: formatTime24(new Date()),
        prayerName: currentPrayerName,
      });
    }, minutes * 60 * 1000);
  };

  const handleTogglePrayerDone = (prayerId: string) => {
    const today = getTodayKey();
    setData(prev => {
      const todayRecord = { ...(prev.done[today] || {}) };
      todayRecord[prayerId] = !todayRecord[prayerId];
      return {
        ...prev,
        done: {
          ...prev.done,
          [today]: todayRecord,
        },
      };
    });
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col font-sans selection:bg-amber-500/30">
      {/* Container restricted to mobile width like native app or max 480px on desktop with dark framing */}
      <div className="w-full max-w-[480px] mx-auto min-h-screen flex flex-col relative border-x border-zinc-900 bg-black">
        {/* Top Header */}
        <Header
          settings={data.settings}
          onOpenSettings={() => setShowSettings(true)}
          onOpenDuas={() => setShowDuas(true)}
          onTriggerTestAlarm={() => handleTriggerTest()}
        />

        {/* Main Tab Views */}
        <main className="flex-1 overflow-x-hidden">
          {tab === 'alarms' && (
            <AlarmsTab
              alarms={data.alarms}
              settings={data.settings}
              onUpdateAlarms={updated => setData(prev => ({ ...prev, alarms: updated }))}
              onSyncWithCalculated={handleSyncWithCalculated}
              onTestAlarm={handleTriggerTest}
            />
          )}

          {tab === 'namaz' && (
            <NamazTab
              alarms={data.alarms}
              doneRecords={data.done}
              settings={data.settings}
              onTogglePrayerDone={handleTogglePrayerDone}
              onOpenSettings={() => setShowSettings(true)}
            />
          )}

          {tab === 'qibla' && (
            <QiblaTab
              settings={data.settings}
              onOpenSettings={() => setShowSettings(true)}
            />
          )}

          {tab === 'tasks' && (
            <TasksTab
              tasks={data.tasks}
              settings={data.settings}
              onUpdateTasks={updated => setData(prev => ({ ...prev, tasks: updated }))}
            />
          )}

          {tab === 'tasbih' && (
            <TasbihTab
              tasbih={data.tasbih}
              onUpdateTasbih={updated => setData(prev => ({ ...prev, tasbih: updated }))}
            />
          )}
        </main>

        {/* Bottom Floating Navigation Bar */}
        <Navigation currentTab={tab} onSelectTab={t => setTab(t)} />

        {/* Toast feedback */}
        {toastMessage && (
          <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-2xl bg-zinc-900/95 border border-amber-500/40 text-amber-300 text-xs font-semibold shadow-2xl flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
            <span>✨</span>
            <span>{toastMessage}</span>
          </div>
        )}

        {/* Ringing Alarm Fullscreen Modal */}
        {ringingAlarm && (
          <RingingAlarmModal
            label={ringingAlarm.label}
            time={ringingAlarm.time}
            prayerName={ringingAlarm.prayerName}
            settings={data.settings}
            onDismiss={() => setRingingAlarm(null)}
            onSnooze={handleSnooze}
          />
        )}

        {/* Settings Modal */}
        {showSettings && (
          <SettingsModal
            settings={data.settings}
            onUpdateSettings={newSettings => {
              setData(prev => ({ ...prev, settings: newSettings }));
              showToast('Settings saved!');
            }}
            onClose={() => setShowSettings(false)}
          />
        )}

        {/* Masnoon Duas Modal */}
        {showDuas && <DuasModal onClose={() => setShowDuas(false)} />}
      </div>
    </div>
  );
}
